/**
 * @file scripts/test-services.ts
 * @description Suite de testes automatizados para validação das regras de negócio,
 * algoritmos científicos de placas e avaliação do Desafio das Cores.
 */

import { generatePseudoisochromaticPlate } from '../src/data/plateGenerators';
import { evaluateLevelAnswers, synthesizeFullSession } from '../src/services/assessmentService';
import { LEVELS_CONFIG, getLevelConfig } from '../src/data/levelsData';

console.log('🧪 Iniciando Bateria de Testes Automatizados...\n');

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, testName: string) {
  totalTests++;
  if (condition) {
    console.log(`✅ [PASSOU] ${testName}`);
    passedTests++;
  } else {
    console.error(`❌ [FALHOU] ${testName}`);
    process.exitCode = 1;
  }
}

// =======================================================
// 1. Validação da Estrutura dos Níveis e Questões
// =======================================================
console.log('--- 1. Validação de Níveis e Eixos de Visão de Cores ---');
assert(LEVELS_CONFIG.length === 3, 'O sistema possui exatamente 3 níveis principais');
assert(LEVELS_CONFIG[0].deficiencyType === 'protan', 'Nível 1 avalia o eixo Protan (Cores Vermelhas)');
assert(LEVELS_CONFIG[1].deficiencyType === 'deutan', 'Nível 2 avalia o eixo Deutan (Cores Verdes)');
assert(LEVELS_CONFIG[2].deficiencyType === 'tritan', 'Nível 3 avalia o eixo Tritan (Cores Azuis)');

LEVELS_CONFIG.forEach((level) => {
  assert(level.questions.length >= 6, `Nível ${level.levelNumber} possui pelo menos 6 questões cadastradas`);
  
  // Placa de controle inicial
  const firstQ = level.questions[0];
  assert(firstQ.difficulty === 'controle', `Nível ${level.levelNumber} inicia com placa de controle para engajamento infantil`);

  // Cada questão possui alternativas com a opção correta
  level.questions.forEach((q) => {
    const hasCorrectChoice = q.choices.some((c) => c.id === q.correctChoiceId);
    assert(hasCorrectChoice, `Questão ${q.id} contém a alternativa correta esperada`);
    assert(q.choices.length === 4, `Questão ${q.id} contém exatamente 4 alternativas de resposta`);
  });
});

// =======================================================
// 2. Validação do Algoritmo Científico de Placas
// =======================================================
console.log('\n--- 2. Validação da Geração de Placas Pseudoisocromáticas ---');
const plateProtan = generatePseudoisochromaticPlate('q1_2_tri', 'protan', 'triangle', 42);
assert(plateProtan.width === 340 && plateProtan.height === 340, 'Dimensões da placa são padronizadas em 340x340');
assert(plateProtan.dots.length > 250, `A placa protan gerou uma densidade adequada de pontos (${plateProtan.dots.length} círculos)`);
assert(plateProtan.dots.every(d => d.radius >= 3.0 && d.radius <= 10.0), 'Todos os pontos possuem variação controlada de tamanho');
assert(plateProtan.dots.every(d => typeof d.color === 'string' && d.color.startsWith('#')), 'Cores atribuídas são hexadecimais válidos com ruído de luminância');

const plateDeutan = generatePseudoisochromaticPlate('q2_2_circle', 'deutan', 'circle', 42);
assert(plateDeutan.dots.length > 250, `Placa deutan gerada com sucesso (${plateDeutan.dots.length} pontos)`);

const plateTritan = generatePseudoisochromaticPlate('q3_2_square', 'tritan', 'square', 42);
assert(plateTritan.dots.length > 250, `Placa tritan gerada com sucesso (${plateTritan.dots.length} pontos)`);

// =======================================================
// 3. Validação do Motor de Avaliação e Não-Diagnóstico
// =======================================================
console.log('\n--- 3. Validação do Cálculo de Acurácia e Diretrizes Éticas ---');
const level1 = getLevelConfig(1);

// Cenário A: Todas as respostas corretas (100%)
const answers100: Record<string, string> = {};
level1.questions.forEach((q) => {
  answers100[q.id] = q.correctChoiceId;
});
const result100 = evaluateLevelAnswers(level1, answers100);
assert(result100.percentage === 100, 'Acurácia é 100% quando todas as questões estão certas');
assert(result100.indicativeStatus === 'sem_indicios', 'Status é "sem_indicios" para acurácia >= 80%');
assert(!result100.interpretation.toLowerCase().includes('diagnóstico:'), 'Interpretação NÃO utiliza termo de diagnóstico');
assert(!result100.interpretation.toLowerCase().includes('você tem daltonismo'), 'Interpretação NÃO afirma que o usuário tem daltonismo');

// Cenário B: Respostas com divergências (< 50%)
const answersLow: Record<string, string> = {};
level1.questions.forEach((q, i) => {
  // Erra a maioria
  answersLow[q.id] = i === 0 ? q.correctChoiceId : 'wrong_id';
});
const resultLow = evaluateLevelAnswers(level1, answersLow);
assert(resultLow.percentage < 50, 'Acurácia reflete acertos parciais');
assert(resultLow.indicativeStatus === 'indicios_significativos', 'Classifica como "indicios_significativos" com cuidado ético');
assert(resultLow.interpretation.includes('NÃO constitui diagnóstico'), 'Interpretação enfatiza explicitamente que não é diagnóstico');

// Cenário C: Síntese Consolidada de Sessão
const mockSession = synthesizeFullSession(
  { name: 'Lucas Gabriel', age: 7, guardian: 'Maria Oliveira' },
  [result100, result100, result100]
);
assert(mockSession.overallPercentage === 100, 'Percentual geral consolidado é calculado corretamente');
assert(mockSession.ethicalDisclaimer.includes('NÃO realiza diagnóstico médico'), 'Disclaimer médico obrigatório está presente');

console.log(`\n🎉 Testes Concluídos: ${passedTests} de ${totalTests} asserções passaram com sucesso!`);
