/**
 * @file components/ProgressBar.tsx
 * @description Indicador visual de progresso animado com ícone do camaleão caminhando
 * em direção ao troféu de conclusão.
 */

import React from 'react';
import { Trophy, Sparkles } from 'lucide-react';

interface ProgressBarProps {
  currentQuestion: number;
  totalQuestions: number;
  levelName: string;
  levelNumber: number;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  currentQuestion,
  totalQuestions,
  levelName,
  levelNumber
}) => {
  const progressPercent = Math.round((currentQuestion / totalQuestions) * 100);

  return (
    <div style={{ width: '100%', marginBottom: '1.5rem' }}>
      {/* Informações do Nível e Pergunta */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '0.75rem',
        flexWrap: 'wrap',
        gap: '0.5rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <span
            className="badge"
            style={{
              backgroundColor: levelNumber === 1 ? '#fee2e2' : levelNumber === 2 ? '#dcfce7' : '#dbeafe',
              color: levelNumber === 1 ? '#dc2626' : levelNumber === 2 ? '#15803d' : '#2563eb',
              fontWeight: 800,
              fontSize: '0.9rem',
              padding: '0.4rem 0.8rem'
            }}
          >
            Nível {levelNumber}
          </span>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 800, margin: 0 }}>
            {levelName}
          </h2>
        </div>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.4rem',
          fontWeight: 800,
          color: 'var(--brand-primary)',
          fontSize: '1.05rem',
          backgroundColor: '#eef2ff',
          padding: '0.35rem 0.85rem',
          borderRadius: 'var(--radius-full)'
        }}>
          <Sparkles size={18} fill="currentColor" />
          <span>Pergunta {currentQuestion} de {totalQuestions}</span>
        </div>
      </div>

      {/* Trilha da Barra com Ícone Caminhante */}
      <div style={{ position: 'relative', width: '100%', paddingTop: '8px' }}>
        <div
          role="progressbar"
          aria-valuenow={progressPercent}
          aria-valuemin={0}
          aria-valuemax={100}
          style={{
            width: '100%',
            height: '18px',
            backgroundColor: '#e2e8f0',
            borderRadius: 'var(--radius-full)',
            overflow: 'hidden',
            padding: '3px',
            boxShadow: 'inset 0 2px 4px rgba(0, 0, 0, 0.08)',
            position: 'relative'
          }}
        >
          <div
            style={{
              width: `${progressPercent}%`,
              height: '100%',
              backgroundImage:
                levelNumber === 1
                  ? 'linear-gradient(90deg, #f87171, #ef4444)'
                  : levelNumber === 2
                  ? 'linear-gradient(90deg, #4ade80, #10b981)'
                  : 'linear-gradient(90deg, #60a5fa, #3b82f6)',
              borderRadius: 'var(--radius-full)',
              transition: 'width 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)'
            }}
          />
        </div>

        {/* Troféu no Final da Trilha */}
        <div
          style={{
            position: 'absolute',
            right: '-6px',
            top: '0px',
            width: '32px',
            height: '32px',
            borderRadius: '50%',
            backgroundColor: '#fef3c7',
            border: '2px solid #f59e0b',
            color: '#d97706',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 2px 6px rgba(0,0,0,0.1)'
          }}
          title="Meta final do desafio!"
        >
          <Trophy size={16} />
        </div>
      </div>
    </div>
  );
};
