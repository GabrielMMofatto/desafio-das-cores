/**
 * @file data/plateGenerators.ts
 * @description Geração de Placas Pseudoisocromáticas com paletas calibradas
 * científicamente para cada eixo de confusão cromática.
 *
 * FUNDAMENTAÇÃO CIENTÍFICA DAS PALETAS:
 *
 * PROTAN (deficiência em cones L - vermelho):
 *   - Pessoas com protanopia/protanomalia confundem VERMELHO com VERDE-OLIVA/MARROM.
 *   - A figura usa vermelho saturado; o fundo usa verde-musgo/oliva.
 *   - Visionadores normais veem o vermelho claramente destacado do verde.
 *   - Protanopes veem ambos com luminosidade similar (confusão).
 *
 * DEUTAN (deficiência em cones M - verde):
 *   - Pessoas com deuteranopia/deuteranomalia confundem VERDE com LARANJA/MARROM.
 *   - A figura usa verde vibrante; o fundo usa laranja-acastanhado/terracota.
 *   - Visionadores normais veem o verde claramente destacado do laranja.
 *   - Deuteranopes veem ambos com cromaticidade similar.
 *
 * TRITAN (deficiência em cones S - azul):
 *   - Pessoas com tritanopia/tritanomalia confundem AZUL com VERDE e AMARELO com ROXO.
 *   - A figura usa azul-royal; o fundo usa amarelo-dourado.
 *   - Visionadores normais veem o contraste azul/amarelo.
 *   - Tritanopes confundem esses tons.
 *
 * CONTROLE: Alto contraste universal (laranja escuro sobre cinza chumbo)
 *   - Visível por qualquer pessoa, inclusive daltonas.
 */

import { SymbolOrNumberType, DeficiencyAxis } from '../types';

export interface PlateDot {
  x: number;
  y: number;
  radius: number;
  color: string;
}

export interface GeneratedPlate {
  id: string;
  width: number;
  height: number;
  dots: PlateDot[];
}

/**
 * Gerador determinístico de números pseudoaleatórios (Mulberry32)
 */
function createSeededRandom(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Paletas cromáticas calibradas conforme eixos de confusão CIE 1931.
 * Cada paleta tem variantes de luminância (claro/médio/escuro) para criar
 * o ruído de luminância necessário sem quebrar o princípio de confusão cromática.
 */
const COLOR_PALETTES: Record<
  DeficiencyAxis,
  {
    foreground: string[]; // Cores da figura
    background: string[]; // Cores do fundo
  }
> = {
  /**
   * EIXO PROTAN
   * Figura: Vermelhos saturados (o cone L responde a estes)
   * Fundo: Verdes-oliva / verde-musgo (linha de confusão protan)
   * Protanopes veem ambos como tons acinzentados similares.
   */
  protan: {
    foreground: [
      '#cc2200', // vermelho escuro
      '#e63030', // vermelho médio
      '#ff4444', // vermelho vivo
      '#d93a3a', // vermelho médio-escuro
      '#b51f1f', // vermelho bordô
      '#f05050', // vermelho claro
      '#c82828', // vermelho profundo
      '#e84040', // vermelho brilhante
    ],
    background: [
      '#4a5e1e', // verde-oliva escuro
      '#6b7c2d', // verde-oliva médio
      '#5c6e22', // verde-musgo
      '#7a8c38', // verde-oliva claro
      '#536020', // verde-cáqui escuro
      '#617228', // verde-musgo médio
      '#839a3a', // verde-oliva vivo
      '#4e5c1c', // verde-oliva muito escuro
    ]
  },

  /**
   * EIXO DEUTAN
   * Figura: Verdes saturados brilhantes (cones M)
   * Fundo: Laranjas-acastanhados / terracota (linha de confusão deutan)
   * Deuteranopes confundem esses tons.
   */
  deutan: {
    foreground: [
      '#1a7a2e', // verde escuro floresta
      '#28a045', // verde médio
      '#35c455', // verde brilhante
      '#22882e', // verde médio-escuro
      '#0f6e24', // verde profundo
      '#2db040', // verde vivo
      '#189032', // verde saturado
      '#3dbe58', // verde claro vivo
    ],
    background: [
      '#7a3010', // marrom-terracota escuro
      '#a04520', // terracota médio
      '#c05a28', // laranja-terracota
      '#8c3818', // marrom avermelhado
      '#b54e22', // laranja-ocre
      '#6e2a0e', // marrom escuro
      '#963e1c', // terracota médio-escuro
      '#d06830', // laranja-ocre claro
    ]
  },

  /**
   * EIXO TRITAN
   * Figura: Azuis saturados (cones S)
   * Fundo: Amarelos-dourados (linha de confusão tritan)
   * Tritanopes confundem azul com verde e amarelo com roxo.
   */
  tritan: {
    foreground: [
      '#0a3db5', // azul royal escuro
      '#1a52d0', // azul médio
      '#2563eb', // azul vivo
      '#1244c8', // azul profundo
      '#0832a8', // azul índigo escuro
      '#1e4fd6', // azul médio-vivo
      '#0e46c0', // azul saturado
      '#2d5de8', // azul brilhante
    ],
    background: [
      '#c8960a', // amarelo-dourado escuro
      '#e0ac10', // amarelo-ouro médio
      '#f5c020', // amarelo-ouro vivo
      '#d4a010', // amarelo-mostarda
      '#b8880a', // dourado escuro
      '#ecb818', // amarelo vivo
      '#caa010', // mostarda saturada
      '#f7cb28', // amarelo claro brilhante
    ]
  },

  /**
   * CONTROLE / DEMONSTRAÇÃO
   * Alto contraste universal — visível por qualquer pessoa.
   * Laranja intenso sobre cinza-azulado escuro.
   */
  control: {
    foreground: [
      '#e05500', // laranja escuro
      '#f06000', // laranja médio
      '#ff6e00', // laranja vivo
      '#e86200', // laranja quente
      '#d85000', // laranja profundo
    ],
    background: [
      '#1e2a38', // cinza-azulado escuro
      '#263444', // cinza-ardósia médio
      '#1a2530', // quase preto-azulado
      '#2c3c4e', // cinza-azulado médio-claro
      '#162030', // muito escuro
    ]
  }
};

/**
 * Funções de máscara geométrica — figuras grandes, sólidas e bem visíveis
 * no mosaico de pontos (figuras com pelo menos 30–40% da área do disco).
 */
function isPointInFigure(
  x: number,
  y: number,
  figure: SymbolOrNumberType,
  cx: number,
  cy: number
): boolean {
  const dx = x - cx;
  const dy = y - cy;

  switch (figure) {
    case 'circle': {
      // Círculo grande e sólido (raio 52px)
      return Math.sqrt(dx * dx + dy * dy) <= 52;
    }

    case 'square': {
      // Quadrado grande (96x96px)
      return Math.abs(dx) <= 48 && Math.abs(dy) <= 48;
    }

    case 'triangle': {
      // Triângulo equilátero grande e espesso
      if (dy < -55 || dy > 48) return false;
      const widthAtY = (48 - dy) * 0.60;
      return Math.abs(dx) <= widthAtY;
    }

    case 'star': {
      // Estrela de 5 pontas grande e sólida
      const angle = Math.atan2(dy, dx) + Math.PI / 2;
      const r = Math.sqrt(dx * dx + dy * dy);
      if (r > 60) return false;
      const normAngle = (angle + 2 * Math.PI) % ((2 * Math.PI) / 5);
      const halfStep = Math.PI / 5;
      const diff = Math.abs(normAngle - halfStep);
      const maxR = 26 + 34 * Math.cos(diff);
      return r <= maxR;
    }

    case 'heart': {
      // Coração sólido grande
      const nx = dx / 50;
      const ny = -dy / 50 + 0.2;
      const a = nx * nx + ny * ny - 1;
      return a * a * a - nx * nx * ny * ny * ny <= 0;
    }

    case 'sun': {
      // Sol: núcleo grande + 8 raios largos e robustos
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist <= 34) return true;
      if (dist <= 58) {
        const angle = (Math.atan2(dy, dx) + Math.PI * 2) % (Math.PI / 4);
        return Math.abs(angle - Math.PI / 8) < 0.22;
      }
      return false;
    }

    case 'boat': {
      // Barco: vela larga + mastro + casco pronunciado
      if (dx >= -2 && dx <= 44 && dy >= -52 && dy <= 8) {
        const maxWidth = (8 - dy) * 0.80;
        if (dx <= maxWidth) return true;
      }
      if (Math.abs(dx) <= 4 && dy >= -54 && dy <= 12) return true;
      if (dy >= 12 && dy <= 42) {
        const progress = (dy - 12) / 30;
        const maxW = 54 - progress * 18;
        return Math.abs(dx) <= maxW;
      }
      return false;
    }

    case 'car': {
      // Carro grande com cabine arredondada + corpo + rodas
      if (dy >= -42 && dy <= -10 && dx >= -30 && dx <= 24) return true;
      if (dy >= -10 && dy <= 24 && dx >= -52 && dx <= 52) return true;
      const dw1 = Math.sqrt((dx + 30) * (dx + 30) + (dy - 24) * (dy - 24));
      const dw2 = Math.sqrt((dx - 30) * (dx - 30) + (dy - 24) * (dy - 24));
      if (dw1 <= 14 || dw2 <= 14) return true;
      return false;
    }

    case 'fish': {
      // Peixe: corpo oval grande + cauda pronunciada
      const ex = dx / 46;
      const ey = dy / 28;
      if (ex * ex + ey * ey <= 1) return true;
      if (dx >= 34 && dx <= 60) {
        const h = (dx - 34) * 1.0;
        return Math.abs(dy) <= h;
      }
      return false;
    }

    case 'num_2': {
      // Número 2 grande e espesso
      const distTop = Math.sqrt(dx * dx + (dy + 24) * (dy + 24));
      if (distTop >= 16 && distTop <= 38 && dy <= -8) return true;
      if (dy > -14 && dy < 36) {
        const expectedX = 20 - (dy + 14) * 0.90;
        if (Math.abs(dx - expectedX) <= 14) return true;
      }
      if (dy >= 30 && dy <= 50 && dx >= -32 && dx <= 36) return true;
      return false;
    }

    case 'num_5': {
      // Número 5 grande e espesso
      if (dy >= -50 && dy <= -32 && dx >= -28 && dx <= 30) return true;
      if (dy >= -38 && dy <= -8 && dx >= -28 && dx <= -10) return true;
      const distB = Math.sqrt(dx * dx + (dy - 16) * (dy - 16));
      if (distB >= 18 && distB <= 38 && (dx >= -14 || dy >= 12)) return true;
      return false;
    }

    case 'num_7': {
      // Número 7 grande e espesso
      if (dy >= -50 && dy <= -32 && dx >= -30 && dx <= 32) return true;
      if (dy >= -34 && dy <= 50) {
        const expectedX = 24 - (dy + 34) * 0.50;
        if (Math.abs(dx - expectedX) <= 14) return true;
      }
      return false;
    }

    case 'num_8': {
      // Número 8 grande — dois anéis sólidos (não vazados)
      const distTop = Math.sqrt(dx * dx + (dy + 22) * (dy + 22));
      const distBottom = Math.sqrt(dx * dx + (dy - 22) * (dy - 22));
      return distTop <= 28 || distBottom <= 30;
    }

    case 'none':
    default:
      return false;
  }
}

/**
 * Gera a placa pseudoisocromática determinística com alta nitidez.
 * Os pontos são posicionados sem sobreposição e com densidade otimizada.
 */
export function generatePseudoisochromaticPlate(
  plateId: string,
  plateType: DeficiencyAxis,
  figure: SymbolOrNumberType,
  seed = 42
): GeneratedPlate {
  const width = 340;
  const height = 340;
  const cx = width / 2;
  const cy = height / 2;
  const plateRadius = 155;

  const rng = createSeededRandom(seed);
  const palette = COLOR_PALETTES[plateType] || COLOR_PALETTES.control;

  const dots: PlateDot[] = [];
  const minRadius = 4.0;
  const maxRadius = 9.0;
  const targetDotsCount = 480;

  let attempts = 0;
  const maxAttempts = 12000;

  while (dots.length < targetDotsCount && attempts < maxAttempts) {
    attempts++;

    // Ponto uniforme dentro do disco da placa
    const rDist = Math.sqrt(rng()) * (plateRadius - maxRadius - 2);
    const angle = rng() * Math.PI * 2;
    const x = cx + Math.cos(angle) * rDist;
    const y = cy + Math.sin(angle) * rDist;

    // Raio aleatório para ruído espacial natural
    const radius = minRadius + rng() * (maxRadius - minRadius);

    // Verifica colisão com pontos existentes
    let collision = false;
    for (let i = 0; i < dots.length; i++) {
      const d = dots[i];
      const distSq = (x - d.x) * (x - d.x) + (y - d.y) * (y - d.y);
      const minDistance = radius + d.radius + 1.0;
      if (distSq < minDistance * minDistance) {
        collision = true;
        break;
      }
    }

    if (!collision) {
      const inFigure = isPointInFigure(x, y, figure, cx, cy);
      const colorChoices = inFigure ? palette.foreground : palette.background;

      // Adiciona variação de luminância ao escolher a cor
      const colorIndex = Math.floor(rng() * colorChoices.length);
      const color = colorChoices[colorIndex];

      dots.push({
        x: Math.round(x * 10) / 10,
        y: Math.round(y * 10) / 10,
        radius: Math.round(radius * 10) / 10,
        color
      });
    }
  }

  return {
    id: plateId,
    width,
    height,
    dots
  };
}
