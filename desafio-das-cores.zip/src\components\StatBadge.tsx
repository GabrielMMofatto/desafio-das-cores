/**
 * @file components/StatBadge.tsx
 * @description Pílula indicadora de status visual com duplo indicador (ícone + texto + cor),
 * em estrita conformidade com acessibilidade visual para daltonismo (WCAG 2.1).
 */

import React from 'react';
import { CheckCircle2, AlertTriangle, HelpCircle } from 'lucide-react';
import { IndicativeStatus } from '../types';

interface StatBadgeProps {
  status: IndicativeStatus;
  percentage?: number;
}

export const StatBadge: React.FC<StatBadgeProps> = ({ status, percentage }) => {
  switch (status) {
    case 'sem_indicios':
      return (
        <span
          className="badge badge-success"
          style={{ fontSize: '0.85rem', padding: '0.35rem 0.8rem', gap: '0.4rem' }}
        >
          <CheckCircle2 size={15} />
          <span>Respostas Esperadas {percentage !== undefined && `(${percentage}%)`}</span>
        </span>
      );

    case 'indicios_leves':
      return (
        <span
          className="badge badge-warning"
          style={{ fontSize: '0.85rem', padding: '0.35rem 0.8rem', gap: '0.4rem' }}
        >
          <HelpCircle size={15} />
          <span>Atenção Leve {percentage !== undefined && `(${percentage}%)`}</span>
        </span>
      );

    case 'indicios_significativos':
      return (
        <span
          className="badge badge-alert"
          style={{ fontSize: '0.85rem', padding: '0.35rem 0.8rem', gap: '0.4rem' }}
        >
          <AlertTriangle size={15} />
          <span>Indícios de Dificuldade {percentage !== undefined && `(${percentage}%)`}</span>
        </span>
      );

    default:
      return null;
  }
};
