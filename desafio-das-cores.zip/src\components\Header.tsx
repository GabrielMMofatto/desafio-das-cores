/**
 * @file components/Header.tsx
 * @description Barra superior com identidade visual do projeto, navegação
 * e controle de efeitos sonoros.
 */

import React, { useState } from 'react';
import { Palette, FileText, Home as HomeIcon, Volume2, VolumeX } from 'lucide-react';
import { AppScreen } from '../types';
import { soundService } from '../services/soundService';

interface HeaderProps {
  currentScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentScreen, onNavigate }) => {
  const [isSoundOn, setIsSoundOn] = useState(soundService.isEnabled());

  const handleToggleSound = () => {
    const newState = soundService.toggleSound();
    setIsSoundOn(newState);
  };

  return (
    <header style={{
      backgroundColor: 'var(--bg-card)',
      borderBottom: '1px solid var(--bg-muted)',
      padding: '0.85rem 1.5rem',
      boxShadow: 'var(--shadow-sm)',
      position: 'sticky',
      top: 0,
      zIndex: 40
    }}>
      <div style={{
        maxWidth: '1024px',
        margin: '0 auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '0.75rem'
      }}>
        {/* Logo / Título */}
        <button
          onClick={() => onNavigate('HOME')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            textAlign: 'left',
            padding: 0
          }}
          aria-label="Ir para a página inicial"
        >
          <div style={{
            width: '44px',
            height: '44px',
            borderRadius: 'var(--radius-lg)',
            backgroundColor: 'var(--brand-primary-light)',
            color: 'var(--brand-primary)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 2px 6px rgba(79, 70, 229, 0.2)'
          }}>
            <Palette size={26} />
          </div>
          <div>
            <span style={{
              fontFamily: 'var(--font-heading)',
              fontSize: '1.3rem',
              fontWeight: 800,
              color: 'var(--text-main)',
              display: 'block',
              lineHeight: 1.1
            }}>
              Desafio das Cores
            </span>
            <span style={{
              fontSize: '0.78rem',
              fontWeight: 700,
              color: 'var(--brand-primary)',
              textTransform: 'uppercase',
              letterSpacing: '0.04em'
            }}>
              Triagem Visual Infantil
            </span>
          </div>
        </button>

        {/* Ações de Navegação e Som */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          {/* Botão de Som */}
          <button
            type="button"
            onClick={handleToggleSound}
            className="btn btn-outline"
            style={{
              padding: '0.5rem 0.75rem',
              minHeight: '40px',
              color: isSoundOn ? 'var(--brand-primary)' : 'var(--text-muted)'
            }}
            title={isSoundOn ? 'Sons ativados (clique para silenciar)' : 'Sons desativados (clique para ativar)'}
            aria-label={isSoundOn ? 'Silenciar efeitos sonoros' : 'Ativar efeitos sonoros'}
          >
            {isSoundOn ? <Volume2 size={19} /> : <VolumeX size={19} />}
          </button>

          {currentScreen !== 'HOME' && (
            <button
              onClick={() => onNavigate('HOME')}
              className="btn btn-outline"
              style={{ padding: '0.5rem 1rem', minHeight: '40px', fontSize: '0.95rem' }}
              title="Voltar ao início"
            >
              <HomeIcon size={18} />
              <span>Início</span>
            </button>
          )}

          <button
            onClick={() => onNavigate('REPORTS_HISTORY')}
            className={`btn ${currentScreen === 'REPORTS_HISTORY' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '0.5rem 1.1rem', minHeight: '40px', fontSize: '0.95rem' }}
            title="Abrir histórico de relatórios"
          >
            <FileText size={18} />
            <span>Relatórios</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
