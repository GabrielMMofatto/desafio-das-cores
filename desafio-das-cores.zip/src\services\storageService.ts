/**
 * @file services/storageService.ts
 * @description Camada de persistência desacoplada para armazenamento dos testes de triagem.
 * 
 * PADRÃO DE PROJETO (REPOSITORY PATTERN):
 * A interface TestRecordRepository define o contrato de persistência.
 * A implementação padrão utiliza LocalStorage do navegador, garantindo 100% de privacidade
 * dos dados da criança (nenhum dado é enviado a servidores externos).
 * 
 * EXTENSIBILIDADE PARA TCC:
 * Caso o projeto evolua futuramente para Firebase Firestore, Supabase ou API REST,
 * basta criar uma nova classe implementando TestRecordRepository sem alterar nenhuma tela.
 */

import { FullSessionResult } from '../types';

export interface TestRecordRepository {
  getAll(): Promise<FullSessionResult[]>;
  getById(id: string): Promise<FullSessionResult | null>;
  save(record: FullSessionResult): Promise<void>;
  deleteById(id: string): Promise<boolean>;
  clearAll(): Promise<void>;
}

const STORAGE_KEY = 'desafio_das_cores_historico_v1';

class LocalStorageTestRecordRepository implements TestRecordRepository {
  public async getAll(): Promise<FullSessionResult[]> {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (!data) return [];
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        // Ordena por data decrescente (mais recentes primeiro)
        return parsed.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      }
      return [];
    } catch (err) {
      console.error('Erro ao ler registros do LocalStorage:', err);
      return [];
    }
  }

  public async getById(id: string): Promise<FullSessionResult | null> {
    const list = await this.getAll();
    return list.find((item) => item.id === id) || null;
  }

  public async save(record: FullSessionResult): Promise<void> {
    const list = await this.getAll();
    const existingIndex = list.findIndex((item) => item.id === record.id);
    if (existingIndex >= 0) {
      list[existingIndex] = record;
    } else {
      list.unshift(record);
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  }

  public async deleteById(id: string): Promise<boolean> {
    const list = await this.getAll();
    const filtered = list.filter((item) => item.id !== id);
    if (filtered.length !== list.length) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
      return true;
    }
    return false;
  }

  public async clearAll(): Promise<void> {
    localStorage.removeItem(STORAGE_KEY);
  }
}

// Instância padrão do repositório
export const storageService: TestRecordRepository = new LocalStorageTestRecordRepository();
