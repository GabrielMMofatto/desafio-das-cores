/**
 * @file pages/GameLevel.tsx
 * @description Tela de execução dos desafios com mascote interativo Cromito,
 * efeitos sonoros e opções visuais bem demarcadas.
 */

import React, { useState } from 'react';
import { ArrowRight, Check } from 'lucide-react';
import { LevelConfig, QuestionChoice } from '../types';
import { ProgressBar } from '../components/ProgressBar';
import { PlateViewer } from '../components/PlateViewer';
import { OptionCard } from '../components/OptionCard';
import { Mascot } from '../components/Mascot';
import { soundService } from '../services/soundService';

interface GameLevelProps {
  levelConfig: LevelConfig;
  onFinishLevel: (answersMap: Record<string, string>) => void;
}

export const GameLevel: React.FC<GameLevelProps> = ({ levelConfig, onFinishLevel }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answersMap, setAnswersMap] = useState<Record<string, string>>({});
  const [selectedChoiceId, setSelectedChoiceId] = useState<string | null>(null);

  const currentQuestion = levelConfig.questions[currentQuestionIndex];
  const totalQuestions = levelConfig.questions.length;
  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;

  // Frases de incentivo do mascote Cromito de acordo com o momento do teste
  const getMascotMessage = () => {
    if (currentQuestionIndex === 0) {
      return 'Vamos começar! Olhe com calma para as bolinhas e toque na figura que você encontrar!';
    }
    if (isLastQuestion) {
      return 'Você chegou à última pergunta desse desafio! Que orgulho da sua atenção!';
    }
    const tips = [
      'Responda no seu ritmo! Não tem pressa nenhuma!',
      'Se não conseguir ver nada, não tem problema, pode escolher "Não vejo nada"!',
      'Você é muito bom observador! Continue assim!',
      'Olhe de pertinho ou de longe para ver o desenho se formar!'
    ];
    return tips[currentQuestionIndex % tips.length];
  };

  const handleSelectChoice = (choiceId: string) => {
    setSelectedChoiceId(choiceId);
  };

  const handleConfirmAnswer = () => {
    if (!selectedChoiceId) return;

    soundService.playConfirm();

    // Registra a resposta da questão atual
    const updatedAnswers = {
      ...answersMap,
      [currentQuestion.id]: selectedChoiceId
    };
    setAnswersMap(updatedAnswers);

    if (isLastQuestion) {
      soundService.playLevelVictory();
      onFinishLevel(updatedAnswers);
    } else {
      setSelectedChoiceId(null);
      setCurrentQuestionIndex((prev) => prev + 1);
    }
  };

  return (
    <div className="animate-fade-in" style={{ maxWidth: '840px', margin: '0 auto', width: '100%' }}>
      {/* Barra de Progresso com Meta Lúdica */}
      <ProgressBar
        currentQuestion={currentQuestionIndex + 1}
        totalQuestions={totalQuestions}
        levelName={levelConfig.friendlyName}
        levelNumber={levelConfig.levelNumber}
      />

      {/* Mascote Cromito com Fala Interativa */}
      <Mascot message={getMascotMessage()} />

      <div className="card" style={{ padding: '2rem 1.5rem', textAlign: 'center', backgroundColor: '#ffffff' }}>
        {/* Título da Pergunta em Destaque */}
        <h3 style={{
          fontSize: 'clamp(1.2rem, 3.5vw, 1.55rem)',
          fontWeight: 800,
          color: 'var(--text-main)',
          marginBottom: '0.5rem',
          lineHeight: 1.3
        }}>
          {currentQuestion.prompt}
        </h3>

        {/* Placa Pseudoisocromática de Alta Definição */}
        <PlateViewer
          plateId={currentQuestion.id}
          plateType={currentQuestion.plateType}
          targetFigure={currentQuestion.targetFigure}
          prompt={currentQuestion.prompt}
        />

        {/* Grade de Alternativas com Ícones Ampliados */}
        <div
          role="radiogroup"
          aria-label="Alternativas de resposta"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
            gap: '1rem',
            margin: '1.5rem 0 2rem 0'
          }}
        >
          {currentQuestion.choices.map((choice: QuestionChoice) => (
            <OptionCard
              key={choice.id}
              choice={choice}
              isSelected={selectedChoiceId === choice.id}
              onSelect={() => handleSelectChoice(choice.id)}
            />
          ))}
        </div>

        {/* Botão de Confirmação com Som e Efeito Tátil */}
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <button
            type="button"
            onClick={handleConfirmAnswer}
            disabled={!selectedChoiceId}
            className="btn btn-primary btn-lg"
            style={{
              minWidth: '300px',
              padding: '1.1rem 2.25rem',
              fontSize: '1.3rem',
              gap: '0.8rem',
              boxShadow: selectedChoiceId
                ? '0 8px 24px rgba(79, 70, 229, 0.4)'
                : 'none'
            }}
          >
            <span>{isLastQuestion ? 'CONCLUIR DESAFIO' : 'CONFIRMAR RESPOSTA'}</span>
            {isLastQuestion ? <Check size={26} strokeWidth={3} /> : <ArrowRight size={26} strokeWidth={3} />}
          </button>
        </div>
      </div>
    </div>
  );
};
