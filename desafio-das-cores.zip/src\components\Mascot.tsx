/**
 * @file components/Mascot.tsx
 * @description Mascote "Cromito, o Camaleão das Cores" com balão de fala infantil
 * para guiar e incentivar a criança ao longo dos desafios.
 */

import React from 'react';

interface MascotProps {
  message: string;
  emotion?: 'happy' | 'excited' | 'thinking' | 'celebrating';
}

export const Mascot: React.FC<MascotProps> = ({ message, emotion = 'happy' }) => {
  return (
    <div
      className="animate-fade-in"
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '1rem',
        margin: '1rem 0 1.5rem 0',
        padding: '0.85rem 1.25rem',
        backgroundColor: '#f0fdf4',
        borderRadius: 'var(--radius-xl)',
        border: '2px solid #bbf7d0',
        boxShadow: '0 4px 12px rgba(34, 197, 94, 0.08)'
      }}
    >
      {/* Ilustração SVG do Mascote Cromito */}
      <div
        className="animate-float"
        style={{
          width: '56px',
          height: '56px',
          flexShrink: 0,
          borderRadius: '50%',
          backgroundColor: '#dcfce7',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          border: '2.5px solid #22c55e',
          boxShadow: '0 2px 8px rgba(34, 197, 94, 0.2)'
        }}
      >
        <svg viewBox="0 0 64 64" width="46" height="46" fill="none">
          {/* Corpo do Camaleão */}
          <ellipse cx="32" cy="34" rx="22" ry="18" fill="#22c55e" />
          <ellipse cx="32" cy="35" rx="18" ry="14" fill="#4ade80" />
          
          {/* Olho grande expressivo */}
          <circle cx="24" cy="26" r="9" fill="#ffffff" stroke="#15803d" strokeWidth="2" />
          <circle cx="25" cy="26" r="4.5" fill="#0f172a" />
          <circle cx="27" cy="24" r="1.5" fill="#ffffff" />

          {/* Crista colorida (arco-íris) */}
          <circle cx="16" cy="18" r="4" fill="#f43f5e" />
          <circle cx="23" cy="14" r="4.5" fill="#f59e0b" />
          <circle cx="31" cy="13" r="4" fill="#3b82f6" />
          <circle cx="39" cy="15" r="3.5" fill="#a855f7" />

          {/* Sorriso simpático */}
          <path
            d={emotion === 'excited' ? 'M 22 36 Q 28 44 34 36' : 'M 24 36 Q 28 41 32 36'}
            stroke="#15803d"
            strokeWidth="2.5"
            strokeLinecap="round"
            fill="none"
          />

          {/* Bochecha corada */}
          <circle cx="35" cy="33" r="3" fill="#f87171" opacity="0.6" />

          {/* Patinhas */}
          <circle cx="20" cy="48" r="4" fill="#16a34a" />
          <circle cx="38" cy="48" r="4" fill="#16a34a" />
        </svg>
      </div>

      {/* Balão de Fala do Mascote */}
      <div style={{ flex: 1 }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.4rem',
          marginBottom: '0.15rem'
        }}>
          <span style={{
            fontSize: '0.8rem',
            fontWeight: 800,
            textTransform: 'uppercase',
            color: '#15803d',
            letterSpacing: '0.04em'
          }}>
            Cromito, o Amigo das Cores:
          </span>
        </div>
        <p style={{
          fontFamily: 'var(--font-heading)',
          fontSize: '1.05rem',
          fontWeight: 700,
          color: '#166534',
          margin: 0,
          lineHeight: 1.35
        }}>
          "{message}"
        </p>
      </div>
    </div>
  );
};
