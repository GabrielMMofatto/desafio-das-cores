/**
 * @file pages/ReportsHistory.tsx
 * @description Área de gerenciamento e histórico dos testes realizados (LocalStorage),
 * com busca por nome, modal de detalhes, emissão de PDF e exclusão com confirmação.
 */

import React, { useState, useEffect } from 'react';
import {
  Search,
  FileDown,
  Eye,
  Trash2,
  AlertTriangle,
  User,
  Calendar,
  ArrowLeft,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { FullSessionResult } from '../types';
import { storageService } from '../services/storageService';
import { generateFullSessionPdf } from '../services/pdfService';
import { StatBadge } from '../components/StatBadge';
import { Modal } from '../components/Modal';
import { DisclaimerBanner } from '../components/DisclaimerBanner';

interface ReportsHistoryProps {
  onBackToHome: () => void;
  onStartNewGame: () => void;
}

export const ReportsHistory: React.FC<ReportsHistoryProps> = ({ onBackToHome, onStartNewGame }) => {
  const [records, setRecords] = useState<FullSessionResult[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<FullSessionResult | null>(null);
  const [isConfirmDeleteAllOpen, setIsConfirmDeleteAllOpen] = useState(false);
  const [recordToDeleteId, setRecordToDeleteId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadRecords = async () => {
    setIsLoading(true);
    try {
      const data = await storageService.getAll();
      setRecords(data);
    } catch (err) {
      console.error('Erro ao carregar histórico:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadRecords();
  }, []);

  // Filtra registros pelo nome da criança
  const filteredRecords = records.filter((r) =>
    r.child.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDeleteSingle = async () => {
    if (!recordToDeleteId) return;
    await storageService.deleteById(recordToDeleteId);
    setRecordToDeleteId(null);
    loadRecords();
  };

  const handleDeleteAll = async () => {
    await storageService.clearAll();
    setIsConfirmDeleteAllOpen(false);
    loadRecords();
  };

  const handleDownloadPdf = (record: FullSessionResult) => {
    generateFullSessionPdf(record);
  };

  return (
    <div className="animate-fade-in" style={{ maxWidth: '960px', margin: '0 auto', width: '100%' }}>
      <DisclaimerBanner compact />

      {/* Cabeçalho da Área */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '1rem',
        margin: '1.25rem 0'
      }}>
        <div>
          <button
            onClick={onBackToHome}
            className="btn btn-outline"
            style={{ padding: '0.4rem 0.8rem', minHeight: '36px', fontSize: '0.9rem', marginBottom: '0.5rem' }}
          >
            <ArrowLeft size={16} />
            <span>Voltar ao Início</span>
          </button>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Histórico de Triagens</h2>
          <p style={{ fontSize: '0.95rem', color: 'var(--text-muted)' }}>
            Registros dos testes visuais realizados e armazenados neste navegador.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.6rem' }}>
          {records.length > 0 && (
            <button
              onClick={() => setIsConfirmDeleteAllOpen(true)}
              className="btn btn-danger"
              style={{ fontSize: '0.95rem', minHeight: '44px', padding: '0.5rem 1rem' }}
            >
              <Trash2 size={18} />
              <span>EXCLUIR HISTÓRICO</span>
            </button>
          )}

          <button
            onClick={onStartNewGame}
            className="btn btn-primary"
            style={{ fontSize: '0.95rem', minHeight: '44px', padding: '0.5rem 1.2rem' }}
          >
            <RotateCcw size={18} />
            <span>NOVO TESTE</span>
          </button>
        </div>
      </div>

      {/* Barra de Busca e Filtro */}
      <div className="card" style={{ padding: '1.25rem', marginBottom: '1.5rem' }}>
        <div style={{ position: 'relative', width: '100%' }}>
          <Search
            size={20}
            style={{
              position: 'absolute',
              left: '1rem',
              top: '50%',
              transform: 'translateY(-50%)',
              color: 'var(--text-muted)'
            }}
          />
          <input
            type="text"
            className="form-input"
            placeholder="Buscar pelo nome da criança..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ paddingLeft: '2.85rem', width: '100%' }}
          />
        </div>
      </div>

      {/* Lista de Registros */}
      {isLoading ? (
        <div className="card text-center" style={{ padding: '3rem' }}>
          <p>Carregando histórico...</p>
        </div>
      ) : filteredRecords.length === 0 ? (
        <div className="card text-center" style={{ padding: '3.5rem 1.5rem' }}>
          <div style={{
            width: '64px',
            height: '64px',
            margin: '0 auto 1rem auto',
            borderRadius: '50%',
            backgroundColor: 'var(--bg-muted)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-muted)'
          }}>
            <User size={32} />
          </div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700 }}>
            {searchTerm ? 'Nenhum teste encontrado para esta busca.' : 'Nenhum teste realizado ainda.'}
          </h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', marginTop: '0.4rem' }}>
            {searchTerm ? 'Tente buscar com outro nome.' : 'Inicie um novo desafio para registrar a primeira triagem!'}
          </p>
          {!searchTerm && (
            <button
              onClick={onStartNewGame}
              className="btn btn-primary"
              style={{ marginTop: '1.5rem' }}
            >
              Realizar Primeiro Desafio
            </button>
          )}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {filteredRecords.map((record) => (
            <div
              key={record.id}
              className="card"
              style={{
                padding: '1.5rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '1rem'
              }}
            >
              {/* Linha Superior: Criança e Data */}
              <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '0.75rem'
              }}>
                <div>
                  <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-main)' }}>
                    {record.child.name}
                  </h3>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '1rem',
                    fontSize: '0.86rem',
                    color: 'var(--text-muted)',
                    marginTop: '0.2rem',
                    flexWrap: 'wrap'
                  }}>
                    <span>Idade: <strong>{record.child.age} anos</strong></span>
                    {record.child.guardian && (
                      <span>Responsável: <strong>{record.child.guardian}</strong></span>
                    )}
                    <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                      <Calendar size={14} />
                      {record.date} às {record.time}
                    </span>
                  </div>
                </div>

                <div style={{
                  padding: '0.4rem 0.85rem',
                  backgroundColor: 'var(--brand-primary-light)',
                  color: 'var(--brand-primary)',
                  borderRadius: 'var(--radius-full)',
                  fontWeight: 800,
                  fontSize: '0.95rem'
                }}>
                  Geral: {record.overallPercentage}%
                </div>
              </div>

              {/* Níveis em Mini-Cards */}
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))',
                gap: '0.75rem'
              }}>
                {record.levels.map((lvl) => (
                  <div
                    key={lvl.levelNumber}
                    style={{
                      padding: '0.75rem',
                      backgroundColor: 'var(--bg-card-subtle)',
                      borderRadius: 'var(--radius-md)',
                      fontSize: '0.85rem'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, marginBottom: '0.25rem' }}>
                      <span>Nível {lvl.levelNumber}</span>
                      <span>{lvl.percentage}%</span>
                    </div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      {lvl.correctAnswers} de {lvl.totalQuestions} acertos
                    </div>
                  </div>
                ))}
              </div>

              {/* Botões de Ação do Registro */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'flex-end',
                gap: '0.6rem',
                borderTop: '1px solid var(--bg-muted)',
                paddingTop: '0.85rem',
                flexWrap: 'wrap'
              }}>
                <button
                  onClick={() => setSelectedRecord(record)}
                  className="btn btn-outline"
                  style={{ padding: '0.45rem 0.9rem', fontSize: '0.9rem', minHeight: '38px' }}
                >
                  <Eye size={16} />
                  <span>VER DETALHES</span>
                </button>

                <button
                  onClick={() => handleDownloadPdf(record)}
                  className="btn btn-secondary"
                  style={{ padding: '0.45rem 0.9rem', fontSize: '0.9rem', minHeight: '38px' }}
                >
                  <FileDown size={16} />
                  <span>GERAR PDF</span>
                </button>

                <button
                  onClick={() => setRecordToDeleteId(record.id)}
                  className="btn btn-outline"
                  style={{
                    padding: '0.45rem 0.75rem',
                    fontSize: '0.9rem',
                    minHeight: '38px',
                    color: 'var(--status-alert-text)'
                  }}
                  title="Excluir este registro"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Detalhes do Teste Selecionado */}
      {selectedRecord && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedRecord(null)}
          title={`Triagem de ${selectedRecord.child.name}`}
          maxWidth="720px"
        >
          <div>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
              gap: '0.75rem',
              marginBottom: '1.25rem',
              backgroundColor: 'var(--bg-card-subtle)',
              padding: '1rem',
              borderRadius: 'var(--radius-md)',
              fontSize: '0.9rem'
            }}>
              <div><strong>Idade:</strong> {selectedRecord.child.age} anos</div>
              <div><strong>Responsável:</strong> {selectedRecord.child.guardian || 'Não informado'}</div>
              <div><strong>Data:</strong> {selectedRecord.date} às {selectedRecord.time}</div>
              <div><strong>Acurácia Geral:</strong> {selectedRecord.overallPercentage}%</div>
            </div>

            {selectedRecord.child.observation && (
              <div style={{ marginBottom: '1.25rem', fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                <strong>Observações:</strong> {selectedRecord.child.observation}
              </div>
            )}

            <h4 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: '0.75rem' }}>
              Desempenho por Eixo:
            </h4>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.5rem' }}>
              {selectedRecord.levels.map((lvl) => (
                <div
                  key={lvl.levelNumber}
                  style={{
                    padding: '0.85rem 1rem',
                    border: '1px solid var(--bg-muted)',
                    borderRadius: 'var(--radius-md)',
                    backgroundColor: '#ffffff'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.35rem' }}>
                    <strong>Nível {lvl.levelNumber} — {lvl.levelName}</strong>
                    <span style={{ fontWeight: 800, color: 'var(--brand-primary)' }}>{lvl.percentage}%</span>
                  </div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: '0.4rem' }}>
                    {lvl.scientificName} ({lvl.correctAnswers} acertos / {lvl.wrongAnswers} divergências)
                  </div>
                  <StatBadge status={lvl.indicativeStatus} />
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '0.5rem' }}>
                    {lvl.interpretation}
                  </p>
                </div>
              ))}
            </div>

            <div style={{
              padding: '0.85rem',
              backgroundColor: '#fffbeb',
              borderRadius: 'var(--radius-md)',
              fontSize: '0.85rem',
              color: '#92400e',
              marginBottom: '1.5rem',
              border: '1px solid #fef3c7'
            }}>
              <strong>Síntese: </strong>{selectedRecord.overallSynthesis}
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="btn btn-outline"
              >
                Fechar
              </button>
              <button
                type="button"
                onClick={() => handleDownloadPdf(selectedRecord)}
                className="btn btn-primary"
              >
                <FileDown size={18} />
                <span>BAIXAR RELATÓRIO PDF</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Modal: Confirmar Exclusão de Registro Individual */}
      {recordToDeleteId && (
        <Modal
          isOpen={true}
          onClose={() => setRecordToDeleteId(null)}
          title="Confirmar Exclusão"
          maxWidth="460px"
        >
          <div>
            <p style={{ fontSize: '0.95rem', color: 'var(--text-secondary)', marginBottom: '1.5rem' }}>
              Tem certeza que deseja excluir o relatório desta criança? Esta ação é irreversível.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button
                type="button"
                onClick={() => setRecordToDeleteId(null)}
                className="btn btn-outline"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteSingle}
                className="btn btn-danger"
              >
                Excluir Registro
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Modal: Confirmar Exclusão de TODO o Histórico */}
      {isConfirmDeleteAllOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsConfirmDeleteAllOpen(false)}
          title="Excluir Todo o Histórico"
          maxWidth="480px"
        >
          <div>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem',
              padding: '0.85rem',
              backgroundColor: '#fff1f2',
              borderRadius: 'var(--radius-md)',
              color: '#9f1239',
              marginBottom: '1.25rem'
            }}>
              <AlertTriangle size={24} style={{ flexShrink: 0 }} />
              <span style={{ fontSize: '0.9rem', fontWeight: 600 }}>
                Atenção: todos os testes salvos neste computador serão apagados permanentemente!
              </span>
            </div>
            <p style={{ fontSize: '0.95rem', color: 'var(--text-secondary)', marginBottom: '1.5rem' }}>
              Deseja realmente apagar todos os registros do histórico?
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button
                type="button"
                onClick={() => setIsConfirmDeleteAllOpen(false)}
                className="btn btn-outline"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteAll}
                className="btn btn-danger"
              >
                Sim, Excluir Tudo
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Rodapé de Privacidade */}
      <div style={{
        marginTop: '2rem',
        padding: '1rem',
        backgroundColor: 'var(--bg-card)',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--bg-muted)',
        display: 'flex',
        alignItems: 'center',
        gap: '0.75rem',
        fontSize: '0.85rem',
        color: 'var(--text-muted)'
      }}>
        <ShieldCheck size={20} color="var(--brand-primary)" style={{ flexShrink: 0 }} />
        <span>
          Os dados listados acima estão armazenados exclusivamente no armazenamento local (LocalStorage) deste dispositivo, sem qualquer compartilhamento externo.
        </span>
      </div>
    </div>
  );
};
