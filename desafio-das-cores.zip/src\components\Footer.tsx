/**
 * @file components/Footer.tsx
 * @description Rodapé institucional com aviso ético e dados acadêmicos do TCC.
 */

import React from 'react';
import { ShieldAlert } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer style={{
      backgroundColor: 'var(--bg-card)',
      borderTop: '1px solid var(--bg-muted)',
      padding: '1.75rem 1rem',
      marginTop: 'auto',
      fontSize: '0.88rem',
      color: 'var(--text-muted)'
    }}>
      <div style={{
        maxWidth: '1024px',
        margin: '0 auto',
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem',
        textAlign: 'center',
        alignItems: 'center'
      }}>
        {/* Aviso de Não Diagnóstico */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          color: '#b45309',
          backgroundColor: '#fffbeb',
          padding: '0.5rem 1rem',
          borderRadius: 'var(--radius-full)',
          fontSize: '0.84rem',
          fontWeight: 600,
          border: '1px solid #fef3c7'
        }}>
          <ShieldAlert size={16} />
          <span>Ferramenta de pré-triagem educativa. NÃO substitui avaliação médica oftalmológica.</span>
        </div>

        <div>
          <p style={{ fontWeight: 600, color: 'var(--text-secondary)' }}>
            Desafio das Cores — Jogo Educativo para Triagem Visual de Daltonismo em Crianças
          </p>
          <p style={{ fontSize: '0.8rem', marginTop: '0.25rem' }}>
            Projeto desenvolvido para Trabalho de Conclusão de Curso (TCC). Dados armazenados localmente e com total privacidade.
          </p>
        </div>
      </div>
    </footer>
  );
};
