# Desafio das Cores — Jogo Educativo para Triagem Visual de Indícios de Daltonismo em Crianças

> **Projeto de Trabalho de Conclusão de Curso (TCC)**  
> **Área:** Ciência da Computação / Informática em Saúde / Tecnologia Educacional  
> **Tema:** Gamificação e Acessibilidade Visual Infantil aplicada à Pré-Triagem de Discromatopsias Congênitas

---

## ⚠️ AVISO ÉTICO E MÉDICO FUNDAMENTAL

> [!IMPORTANT]
> **ESTE SISTEMA NÃO REALIZA DIAGNÓSTICO MÉDICO.**
> Trata-se estritamente de uma ferramenta pedagógica e interativa de **pré-triagem visual**, cujo objetivo é auxiliar pais, educadores e cuidadores a identificar possíveis indícios e dificuldades na diferenciação de cores por crianças.
> O resultado obtido **NÃO substitui sob hipótese alguma** uma consulta e avaliação clínica completa realizada por um **médico oftalmologista** ou profissional especializado em saúde ocular.

---

## 1. Descrição do Projeto

O **Desafio das Cores** é uma aplicação web gamificada desenvolvida especificamente para o público infantil (faixa etária recomendada de 4 a 12 anos). Através de desafios interativos com placas visuais pseudoisocromáticas autorais com ruído de luminância, a aplicação avalia o reconhecimento de estímulos em três eixos ópticos correspondentes às principais deficiências congênitas de visão de cores.

Ao término de cada nível e ao final da sessão de testes, o sistema gera relatórios analíticos em PDF prontos para apresentação a responsáveis e pedagogos, além de manter um histórico local seguro das avaliações realizadas.

---

## 2. Fundamentação Científica e Oftalmológica

A percepção humana tricromática das cores depende de três tipos de fotorreceptores cônicos na retina, cada um contendo fotopigmentos sensíveis a diferentes comprimentos de onda:

1. **Eixo Protan (Nível 1 — "Desafio das Cores Vermelhas")**:
   - **Fotorreceptor:** Cones **L** (*Long-wavelength*).
   - **Fotopigmento:** Eritrolábio (pico de absorção em ~564 nm).
   - **Deficiência:** Protanopia (ausência total) ou Protanomalia (anomalia parcial).
   - **Mecanismo:** Dificuldade em distinguir tonalidades vermelhas de tons verdes-oliva, cáqui e cinzas escuros.
2. **Eixo Deutan (Nível 2 — "Desafio das Cores Verdes")**:
   - **Fotorreceptor:** Cones **M** (*Medium-wavelength*).
   - **Fotopigmento:** Clorolábio (pico de absorção em ~534 nm).
   - **Deficiência:** Deuteranopia (ausência total) ou Deuteranomalia (anomalia parcial — tipo mais comum na população).
   - **Mecanismo:** Dificuldade na discriminação entre verde, marrom-claro, cáqui e terracota.
3. **Eixo Tritan (Nível 3 — "Desafio das Cores Azuis")**:
   - **Fotorreceptor:** Cones **S** (*Short-wavelength*).
   - **Fotopigmento:** Cianolábio (pico de absorção em ~420 nm).
   - **Deficiência:** Tritanopia ou Tritanomalia (herança autossômica dominante, mais rara).
   - **Mecanismo:** Dificuldade na separação do eixo azul-violeta e amarelo.

### Placas Pseudoisocromáticas com Ruído de Luminância
Para garantir validade aos testes sem utilizar materiais proprietários ou imagens comerciais protegidas por direitos autorais:
- As placas são geradas deterministicamente via algoritmo vetorial (`PlateGenerators.ts`).
- Cada placa é composta por um mosaico de centenas de pontos circulares com raios variando de 4,5px a 11px.
- **Ruído de Luminância (Luminance Noise):** Tanto a figura quanto o fundo possuem uma ampla gama de luminosidades e saturações sobrepostas. Isso impede que uma criança com deficiência cromática consiga deduzir a figura baseando-se no brilho ou escuridão dos pontos.
- **Placas de Demonstração/Controle:** Todos os níveis iniciam com uma placa de alto contraste cromático/luminoso para garantir que a criança compreendeu o que é para fazer antes de iniciar o teste de confusão.

---

## 3. Tecnologias Utilizadas

- **Frontend Core:** React 18+ com TypeScript
- **Bundler e Dev Server:** Vite 6
- **Estilização:** CSS3 Moderno, variáveis CSS personalizadas e micro-animações (sem dependência pesada de frameworks utilitários externos, permitindo total controle cromático da interface neutra)
- **Ícones Acessíveis:** Lucide React
- **Geração de Relatórios:** jsPDF + jsPDF-autotable (geração 100% no navegador, sem tráfego de rede)
- **Efeitos de Gamificação:** Canvas-Confetti
- **Persistência de Dados:** LocalStorage desacoplado via padrão *Repository*

---

## 4. Estrutura de Pastas do Projeto

```
desafio-das-cores/
├── public/
│   └── favicon.svg              # Ícone da aplicação
├── src/
│   ├── components/              # Componentes de interface reutilizáveis
│   │   ├── DisclaimerBanner.tsx # Aviso médico/legal obrigatório
│   │   ├── Footer.tsx           # Rodapé institucional do TCC
│   │   ├── Header.tsx           # Topbar e navegação
│   │   ├── Modal.tsx            # Janela modal acessível (teclado Esc)
│   │   ├── OptionCard.tsx       # Alternativas de resposta (ícones e números)
│   │   ├── PlateViewer.tsx      # Renderizador SVG da placa pseudoisocromática
│   │   ├── ProgressBar.tsx      # Barra de progresso do nível
│   │   └── StatBadge.tsx        # Indicador de métricas com duplo canal (ícone + texto)
│   ├── data/                    # Modelagem dos testes e geradores
│   │   ├── levelsData.ts        # Configurações dos 3 níveis e banco de questões
│   │   └── plateGenerators.ts   # Algoritmo matemático de pontos e ruído de luminância
│   ├── pages/                   # Telas que compõem os fluxos do jogo
│   │   ├── ChildRegistration.tsx# Formulário de cadastro da criança
│   │   ├── FinalResult.tsx      # Conclusão dos 3 níveis e síntese geral
│   │   ├── GameLevel.tsx        # Execução das perguntas (sem viés de resposta imediata)
│   │   ├── Home.tsx             # Tela inicial com botões Jogar e Relatórios
│   │   ├── Instructions.tsx     # Recomendações ergonômicas e visuais
│   │   ├── LevelResult.tsx      # Resultado parcial por nível e PDF imediato
│   │   └── ReportsHistory.tsx   # Histórico completo com busca e exclusão
│   ├── services/                # Regras de negócio e persistência
│   │   ├── assessmentService.ts # Cálculo de acurácia e parecer neutro
│   │   ├── pdfService.ts        # Geração dos relatórios em PDF (individual e completo)
│   │   └── storageService.ts    # Repositório LocalStorage (extensível para Firebase/Supabase)
│   ├── styles/                  # Design System neutro para não fadigar a retina
│   │   ├── animations.css       # Keyframes e transições suaves
│   │   ├── global.css           # Estilos globais e utilitários
│   │   └── variables.css        # Paleta acessível e tokens
│   ├── types/                   # Contratos e modelos TypeScript
│   │   └── index.ts
│   ├── App.tsx                  # Gerenciador de estados e fluxo da aplicação
│   └── main.tsx                 # Entrada React
├── index.html                   # HTML base com fontes Inter e Outfit
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md                    # Documentação acadêmica
```

---

## 5. Como Instalar e Executar

### Pré-requisitos
- Node.js (versão 18 ou superior instalada)
- Gerenciador de pacotes npm ou pnpm

### Passo 1: Instalação das dependências
Abra o terminal no diretório do projeto e execute:
```bash
npm install
```

### Passo 2: Execução em modo de desenvolvimento
```bash
npm run dev
```
O Vite iniciará o servidor local, exibindo um link como `http://localhost:3000`. Abra este endereço no navegador.

### Passo 3: Compilação de Produção
Para validar a tipagem e gerar o pacote de produção otimizado:
```bash
npm run build
```

---

## 6. Fluxos de Utilização da Aplicação

### Fluxo Principal de Triagem
1. **Tela Inicial:** Apresentação, advertência ética e botão **[JOGAR]**.
2. **Cadastro da Criança:** Inserção do nome, idade (obrigatórios), responsável e observações (opcionais).
3. **Instruções:** Recomendações de iluminação ambiente, distância da tela (~40-50 cm) e desativação de filtros amarelos/luz noturna.
4. **Nível 1 (Desafio das Cores Vermelhas - Eixo Protan):** 6 perguntas visuais com placas de ruído de luminância. Não há resposta imediata de certo/errado para não gerar viés.
5. **Resultado do Nível 1:** Exibição de acertos, erros, percentual e parecer neutro. Botão para **Baixar PDF do Nível 1** e botão para avançar ao Nível 2.
6. **Nível 2 (Desafio das Cores Verdes - Eixo Deutan):** Mesma dinâmica, focado no fotopigmento clorolábio.
7. **Resultado do Nível 2:** Estatísticas do nível e opção de emissão de PDF do Nível 2.
8. **Nível 3 (Desafio das Cores Azuis - Eixo Tritan):** Desafios no eixo azul-amarelo (cianolábio).
9. **Resultado do Nível 3:** Estatísticas do nível e opção de emissão de PDF do Nível 3.
10. **Resultado Final Consolidado:** Visão geral em cards comparativos dos três níveis, síntese descritiva, celebração infantil, botão para **Baixar Relatório Completo (PDF)** e salvamento automático no histórico local.

### Fluxo de Relatórios e Histórico
1. **Acesso:** Botão **[RELATÓRIOS]** na tela inicial ou na navegação superior.
2. **Busca:** Campo de busca em tempo real pelo nome da criança.
3. **Visualização Detalhada:** Botão **[VER DETALHES]** abre modal com todos os dados da sessão.
4. **Exportação de PDF:** Botão **[GERAR PDF]** emite o relatório formatado do teste selecionado.
5. **Exclusão:** Possibilidade de excluir registros individuais ou utilizar o botão **[EXCLUIR HISTÓRICO]** (com modal de confirmação para prevenir perda acidental de dados).

---

## 7. Acessibilidade e Diretrizes de Design (WCAG 2.1)

- **Cores Neutras na Interface:** A interface utiliza tons de ardósia/slate e fundos esbranquiçados neutros (#F8FAFC). Evitou-se o uso de fundos vermelhos ou verdes na carcaça do jogo para não causar saturação ou adaptação cromática prévia na retina da criança.
- **Não dependência de cor para feedbacks:** Status de acurácia, erros e alternativas utilizam sempre ícones (estrelas, check, alertas), formas geométricas e textos descritivos simultaneamente, nunca apenas cores.
- **Dimensões Táteis:** Botões grandes e espaçados com altura mínima superior a 48px, ideais para interação por toque em tablets e celulares por crianças pequenas.
- **Navegação por Teclado:** Suporte completo a navegação via `Tab`, seleção com `Enter`/`Espaço` e fechamento de diálogos com a tecla `Esc`.

---

## 8. Segurança e Privacidade dos Dados (LGPD)

- **Armazenamento 100% Local:** Os dados cadastrais da criança e os resultados dos testes permanecem estritamente gravados no `localStorage` do navegador da máquina utilizada.
- **Sem Telemetria ou Rastreamento:** Nenhuma informação é enviada a servidores remotos, serviços de analytics ou terceiros.
- **Direito ao Esquecimento:** A área de relatórios permite a qualquer momento apagar registros individualmente ou limpar integralmente todo o histórico da aplicação.

---

## 9. Limitações Conhecidas do Sistema

1. **Calibração de Telas:** Monitores e dispositivos móveis possuem diferentes espaços de cor (sRGB, DCI-P3), perfis de brilho e contrastes variáveis, o que pode influenciar a fidelidade cromática dos testes.
2. **Iluminação Ambiental:** Ambientes excessivamente escuros, lâmpadas com temperatura de cor quente (< 3000K) ou reflexos no display podem alterar a percepção dos tons das placas.
3. **Fator Cognitivo Infantil:** Crianças muito jovens (abaixo de 4 anos) podem ter dificuldades de atenção ou de interpretação das alternativas simbólicas. Por isso, recomenda-se a presença de um responsável ou professor durante toda a atividade.

---

## 10. Conclusão Acadêmica

O projeto **Desafio das Cores** demonstra a viabilidade do uso de técnicas modernas de desenvolvimento web e gamificação pedagógica na facilitação do rastreio precoce de indícios de discromatopsias na infância. A identificação precoce dessas alterações possibilita que escolas e famílias adaptem materiais didáticos e metodologias de ensino, evitando prejuízos pedagógicos e promovendo a inclusão escolar.
