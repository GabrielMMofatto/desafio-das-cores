/**
 * @file services/assessmentService.ts
 * @description Motor de cálculo e interpretação neutra dos testes de triagem visual.
 * 
 * DIRETRIZ ÉTICA E MÉDICA RIGOROSA:
 * Sob nenhuma circunstância este serviço emitirá a palavra "diagnóstico", "você é daltônico"
 * ou "a criança tem daltonismo". O parecer é estritamente descritivo de desempenho
 * em ferramenta de pré-triagem educativa, sempre recomendando exame médico especializado.
 */

import { LevelConfig, LevelResult, IndicativeStatus, FullSessionResult, ChildData } from '../types';

export const MANDATORY_MEDICAL_DISCLAIMER =
  'IMPORTANTE: Este sistema é uma ferramenta de triagem educativa e visual. Ele NÃO realiza diagnóstico médico nem substitui uma consulta completa com um médico oftalmologista ou profissional de saúde visual habilitado.';

export function evaluateLevelAnswers(
  levelConfig: LevelConfig,
  answersMap: Record<string, string> // questionId -> chosenChoiceId
): LevelResult {
  let correctCount = 0;
  const answeredDetails: LevelResult['answers'] = [];

  levelConfig.questions.forEach((q) => {
    const chosen = answersMap[q.id] || '';
    const isCorrect = chosen === q.correctChoiceId;
    if (isCorrect) {
      correctCount++;
    }

    answeredDetails.push({
      questionId: q.id,
      chosenChoiceId: chosen,
      correctChoiceId: q.correctChoiceId,
      isCorrect,
      targetFigure: q.targetFigure
    });
  });

  const total = levelConfig.questions.length;
  const wrongCount = total - correctCount;
  const percentage = Math.round((correctCount / total) * 100);

  let indicativeStatus: IndicativeStatus = 'sem_indicios';
  let interpretation = '';
  let recommendation = '';

  if (percentage >= 80) {
    indicativeStatus = 'sem_indicios';
    interpretation =
      'Durante este desafio não foram observadas alterações significativas nas respostas apresentadas. A criança demonstrou boa capacidade de identificação das figuras e contrastes deste eixo cromático.';
    recommendation =
      'O desempenho apresentado encontra-se dentro dos padrões esperados para esta atividade lúdica de triagem. Acompanhamento oftalmológico preventivo anual de rotina é sempre recomendado na infância.';
  } else if (percentage >= 50) {
    indicativeStatus = 'indicios_leves';
    interpretation =
      'Foram observadas algumas respostas divergentes que podem sugerir atenção leve ou eventual hesitação na diferenciação de certas tonalidades avaliadas neste nível.';
    recommendation =
      'Recomenda-se repetir a atividade em momento oportuno, em ambiente com iluminação natural uniforme e sem reflexos na tela. Caso persistam dúvidas, consulte um médico oftalmologista.';
  } else {
    indicativeStatus = 'indicios_significativos';
    interpretation =
      'Durante este teste foram observadas respostas que podem indicar dificuldade na diferenciação de determinadas cores avaliadas. Esse resultado indica necessidade de atenção, mas NÃO constitui diagnóstico de daltonismo.';
    recommendation =
      'Recomenda-se que este relatório seja apresentado aos pais ou responsáveis e que a criança seja encaminhada a um médico oftalmologista para uma avaliação clínica e oftalmológica completa.';
  }

  return {
    levelNumber: levelConfig.levelNumber,
    type: levelConfig.deficiencyType,
    levelName: levelConfig.friendlyName,
    scientificName: levelConfig.scientificName,
    totalQuestions: total,
    correctAnswers: correctCount,
    wrongAnswers: wrongCount,
    percentage,
    indicativeStatus,
    interpretation,
    recommendation,
    answers: answeredDetails
  };
}

export function synthesizeFullSession(
  child: ChildData,
  levelResults: LevelResult[]
): FullSessionResult {
  const now = new Date();
  const dateFormatted = now.toLocaleDateString('pt-BR');
  const timeFormatted = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

  const totalPossible = levelResults.reduce((acc, curr) => acc + curr.totalQuestions, 0);
  const totalCorrect = levelResults.reduce((acc, curr) => acc + curr.correctAnswers, 0);
  const overallPercentage = totalPossible > 0 ? Math.round((totalCorrect / totalPossible) * 100) : 0;

  const hasSignificantIssue = levelResults.some((l) => l.indicativeStatus === 'indicios_significativos');
  const hasMildIssue = levelResults.some((l) => l.indicativeStatus === 'indicios_leves');

  let overallSynthesis = '';
  if (hasSignificantIssue) {
    overallSynthesis =
      'A triagem identificou indícios de possível dificuldade na diferenciação cromática em um ou mais eixos analisados. Ressaltamos que este resultado tem finalidade pedagógica e de triagem, sendo fundamental o parecer de um médico oftalmologista para investigação clínica.';
  } else if (hasMildIssue) {
    overallSynthesis =
      'A triagem apontou desempenho com leves variações em determinados estímulos visuais. Sugere-se acompanhar o desenvolvimento visual da criança e realizar exames oftalmológicos regulares.';
  } else {
    overallSynthesis =
      'Não foram observados indícios de dificuldade na percepção das cores nos três níveis avaliados. A criança apresentou ótima acurácia na identificação dos estímulos lúdicos.';
  }

  return {
    id: `teste_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    date: dateFormatted,
    time: timeFormatted,
    timestamp: now.getTime(),
    child,
    levels: levelResults,
    overallPercentage,
    overallSynthesis,
    ethicalDisclaimer: MANDATORY_MEDICAL_DISCLAIMER
  };
}
