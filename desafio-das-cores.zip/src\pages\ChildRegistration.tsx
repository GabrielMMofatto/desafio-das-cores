/**
 * @file pages/ChildRegistration.tsx
 * @description Formulário amigável com auxílio do mascote Cromito para cadastro infantil.
 */

import React, { useState } from 'react';
import { User, Calendar, UserCheck, FileEdit, ArrowRight, ArrowLeft } from 'lucide-react';
import { ChildData } from '../types';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { Mascot } from '../components/Mascot';

interface ChildRegistrationProps {
  onRegister: (data: ChildData) => void;
  onCancel: () => void;
}

export const ChildRegistration: React.FC<ChildRegistrationProps> = ({ onRegister, onCancel }) => {
  const [name, setName] = useState('');
  const [age, setAge] = useState<number | ''>('');
  const [guardian, setGuardian] = useState('');
  const [observation, setObservation] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Por favor, informe o nome da criança.');
      return;
    }
    if (!age || age < 3 || age > 18) {
      setErrorMsg('Por favor, informe uma idade válida (entre 3 e 18 anos).');
      return;
    }

    setErrorMsg('');
    onRegister({
      name: name.trim(),
      age: Number(age),
      guardian: guardian.trim() || undefined,
      observation: observation.trim() || undefined
    });
  };

  return (
    <div className="animate-fade-in" style={{ maxWidth: '680px', margin: '0 auto', width: '100%' }}>
      <DisclaimerBanner compact />

      {/* Mascote incentivador */}
      <Mascot
        message="Como você se chama? Digite seu nome para eu preparar seu certificado no final!"
        emotion="happy"
      />

      <div className="card" style={{ padding: '2rem 1.75rem', backgroundColor: '#ffffff' }}>
        <div style={{ textAlign: 'center', marginBottom: '1.75rem' }}>
          <h2 style={{ fontSize: '1.65rem', fontWeight: 800 }}>Quem vai jogar hoje? 🎈</h2>
          <p style={{ fontSize: '1rem', color: 'var(--text-secondary)' }}>
            Preencha os dados abaixo para iniciar sua aventura pelas cores!
          </p>
        </div>

        {errorMsg && (
          <div
            role="alert"
            style={{
              padding: '0.85rem 1rem',
              backgroundColor: 'var(--status-alert-bg)',
              color: 'var(--status-alert-text)',
              border: '1.5px solid var(--status-alert-border)',
              borderRadius: 'var(--radius-md)',
              marginBottom: '1.25rem',
              fontSize: '0.95rem',
              fontWeight: 700
            }}
          >
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          {/* Nome da Criança */}
          <div className="form-group">
            <label htmlFor="child-name" className="form-label" style={{ fontSize: '1.05rem' }}>
              <User size={20} color="var(--brand-primary)" />
              Nome da Criança *
            </label>
            <input
              id="child-name"
              type="text"
              required
              className="form-input"
              style={{ fontSize: '1.15rem', padding: '0.95rem 1.1rem' }}
              placeholder="Digite seu nome (Ex: Lucas Gabriel)"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoFocus
            />
          </div>

          {/* Idade */}
          <div className="form-group">
            <label htmlFor="child-age" className="form-label" style={{ fontSize: '1.05rem' }}>
              <Calendar size={20} color="var(--brand-primary)" />
              Idade (anos) *
            </label>
            <input
              id="child-age"
              type="number"
              required
              min={3}
              max={18}
              className="form-input"
              style={{ fontSize: '1.15rem', padding: '0.95rem 1.1rem' }}
              placeholder="Quantos anos você tem? (Ex: 7)"
              value={age}
              onChange={(e) => setAge(e.target.value ? Number(e.target.value) : '')}
            />
            <span className="form-hint">Recomendado para crianças a partir de 4 anos.</span>
          </div>

          {/* Nome do Responsável (Opcional) */}
          <div className="form-group">
            <label htmlFor="guardian-name" className="form-label" style={{ fontSize: '1.05rem' }}>
              <UserCheck size={20} color="var(--brand-primary)" />
              Nome do Responsável ou Educador (Opcional)
            </label>
            <input
              id="guardian-name"
              type="text"
              className="form-input"
              placeholder="Ex: Mãe, Pai ou Professor(a)"
              value={guardian}
              onChange={(e) => setGuardian(e.target.value)}
            />
          </div>

          {/* Observações (Opcional) */}
          <div className="form-group">
            <label htmlFor="child-obs" className="form-label" style={{ fontSize: '1.05rem' }}>
              <FileEdit size={20} color="var(--brand-primary)" />
              Observações (Opcional)
            </label>
            <textarea
              id="child-obs"
              rows={2}
              className="form-textarea"
              placeholder="Ex: Usa óculos de grau; iluminação natural de dia."
              value={observation}
              onChange={(e) => setObservation(e.target.value)}
            />
          </div>

          {/* Botões de Ação */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
            marginTop: '2rem'
          }}>
            <button
              type="button"
              onClick={onCancel}
              className="btn btn-outline"
              style={{ fontSize: '1.05rem' }}
            >
              <ArrowLeft size={18} />
              <span>Voltar</span>
            </button>

            <button
              type="submit"
              className="btn btn-primary btn-lg"
              style={{ flex: 1, fontSize: '1.25rem' }}
            >
              <span>VAMOS COMEÇAR!</span>
              <ArrowRight size={22} />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
