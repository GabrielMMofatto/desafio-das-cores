/**
 * @file pages/Home.tsx
 * @description Tela inicial amigável e atraente para crianças com o mascote Cromito.
 */

import React from 'react';
import { Play, FileText, Sparkles, ShieldCheck } from 'lucide-react';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { Mascot } from '../components/Mascot';

interface HomeProps {
  onStartGame: () => void;
  onOpenReports: () => void;
}

export const Home: React.FC<HomeProps> = ({ onStartGame, onOpenReports }) => {
  return (
    <div className="animate-fade-in" style={{ maxWidth: '840px', margin: '0 auto', width: '100%' }}>
      {/* Banner Ético/Médico Permanente */}
      <DisclaimerBanner />

      {/* Mascote Cromito com mensagem de boas-vindas */}
      <Mascot
        message="Oi, amiguinho! Sou o Cromito, o camaleão das cores! Vamos jogar e descobrir desenhos mágicos escondidos?"
        emotion="excited"
      />

      {/* Hero Principal Lúdico */}
      <div
        className="card"
        style={{
          textAlign: 'center',
          padding: '2.5rem 1.75rem',
          margin: '1.25rem 0',
          position: 'relative',
          overflow: 'hidden',
          backgroundColor: '#ffffff',
          border: '2px solid #e2e8f0',
          boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.08)'
        }}
      >
        <div style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '0.5rem',
          backgroundColor: '#fef3c7',
          color: '#d97706',
          padding: '0.45rem 1.1rem',
          borderRadius: 'var(--radius-full)',
          fontWeight: 800,
          fontSize: '0.95rem',
          marginBottom: '1rem'
        }}>
          <Sparkles size={18} fill="currentColor" />
          <span>Jogo Educativo Infantil</span>
        </div>

        <h1 style={{
          fontSize: 'clamp(2rem, 5vw, 2.75rem)',
          marginBottom: '0.75rem',
          color: 'var(--text-main)',
          fontWeight: 900
        }}>
          Desafio das Cores 🎨
        </h1>

        <p style={{
          fontSize: '1.25rem',
          fontWeight: 600,
          color: 'var(--text-secondary)',
          maxWidth: '580px',
          margin: '0 auto 2rem auto',
          lineHeight: 1.4
        }}>
          Um jogo super divertido para você descobrir como os seus olhos enxergam as cores!
        </p>

        {/* Botões Principais de Ação com Destaque */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '1rem',
          maxWidth: '480px',
          margin: '0 auto'
        }}>
          <button
            onClick={onStartGame}
            className="btn btn-primary btn-lg w-full"
            style={{
              fontSize: '1.45rem',
              gap: '1rem',
              padding: '1.25rem 2.5rem',
              borderRadius: 'var(--radius-xl)',
              boxShadow: '0 8px 24px rgba(79, 70, 229, 0.35)'
            }}
          >
            <Play size={32} fill="currentColor" />
            <span>JOGAR AGORA!</span>
          </button>

          <button
            onClick={onOpenReports}
            className="btn btn-secondary btn-lg w-full"
            style={{
              fontSize: '1.2rem',
              gap: '0.8rem',
              padding: '1rem 2rem',
              borderRadius: 'var(--radius-xl)'
            }}
          >
            <FileText size={24} />
            <span>RELATÓRIOS E HISTÓRICO</span>
          </button>
        </div>
      </div>

      {/* Cards com os 3 Mundos Coloridos */}
      <div style={{ marginTop: '2rem' }}>
        <h3 style={{
          fontSize: '1.2rem',
          fontWeight: 800,
          color: 'var(--text-main)',
          marginBottom: '1rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem'
        }}>
          <span>Nossos Três Desafios:</span>
        </h3>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '1rem'
        }}>
          {/* Nível 1 */}
          <div className="card" style={{
            padding: '1.35rem',
            borderTop: '5px solid #ef4444',
            backgroundColor: '#ffffff'
          }}>
            <span className="badge badge-alert" style={{ marginBottom: '0.5rem', fontWeight: 800 }}>
              Desafio 1
            </span>
            <h4 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-main)' }}>
              Mundo das Cores Vermelhas 🍓
            </h4>
            <p style={{ fontSize: '0.9rem', marginTop: '0.4rem', color: 'var(--text-secondary)' }}>
              Descubra figuras e desenhos em tons avermelhados (Triagem de Protanopia).
            </p>
          </div>

          {/* Nível 2 */}
          <div className="card" style={{
            padding: '1.35rem',
            borderTop: '5px solid #10b981',
            backgroundColor: '#ffffff'
          }}>
            <span className="badge badge-success" style={{ marginBottom: '0.5rem', fontWeight: 800 }}>
              Desafio 2
            </span>
            <h4 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-main)' }}>
              Mundo das Cores Verdes 🐸
            </h4>
            <p style={{ fontSize: '0.9rem', marginTop: '0.4rem', color: 'var(--text-secondary)' }}>
              Encontre os animais e formas escondidos nos tons da floresta (Triagem de Deuteranopia).
            </p>
          </div>

          {/* Nível 3 */}
          <div className="card" style={{
            padding: '1.35rem',
            borderTop: '5px solid #3b82f6',
            backgroundColor: '#ffffff'
          }}>
            <span className="badge badge-info" style={{ marginBottom: '0.5rem', fontWeight: 800 }}>
              Desafio 3
            </span>
            <h4 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-main)' }}>
              Mundo das Cores Azuis 🐳
            </h4>
            <p style={{ fontSize: '0.9rem', marginTop: '0.4rem', color: 'var(--text-secondary)' }}>
              Diferencie as cores do céu, do oceano e do sol dourado (Triagem de Tritanopia).
            </p>
          </div>
        </div>
      </div>

      {/* Selo de Privacidade */}
      <div style={{
        marginTop: '1.75rem',
        padding: '1rem',
        backgroundColor: '#ffffff',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid #e2e8f0',
        display: 'flex',
        alignItems: 'center',
        gap: '0.85rem',
        fontSize: '0.88rem',
        color: 'var(--text-secondary)'
      }}>
        <ShieldCheck size={24} color="var(--brand-primary)" style={{ flexShrink: 0 }} />
        <span>
          <strong>Ambiente Seguro:</strong> Os dados da criança não são compartilhados com nenhum servidor ou serviço de internet. Tudo fica seguro na memória local deste computador.
        </span>
      </div>
    </div>
  );
};
