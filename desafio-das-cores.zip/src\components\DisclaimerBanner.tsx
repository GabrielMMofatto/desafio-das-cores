/**
 * @file components/DisclaimerBanner.tsx
 * @description Banner destacado com aviso médico obrigatório em cumprimento às normas éticas.
 */

import React from 'react';
import { AlertCircle } from 'lucide-react';

interface DisclaimerBannerProps {
  compact?: boolean;
}

export const DisclaimerBanner: React.FC<DisclaimerBannerProps> = ({ compact = false }) => {
  return (
    <div
      className="disclaimer-box"
      role="alert"
      style={{
        padding: compact ? '0.65rem 1rem' : '0.9rem 1.25rem',
        fontSize: compact ? '0.85rem' : '0.92rem'
      }}
    >
      <AlertCircle size={compact ? 18 : 22} style={{ flexShrink: 0, marginTop: '2px' }} />
      <div>
        <strong>Aviso Importante: </strong>
        Este jogo é uma atividade de triagem visual e <u>não realiza diagnóstico</u> de daltonismo. O resultado não substitui a avaliação completa feita por um médico oftalmologista.
      </div>
    </div>
  );
};
