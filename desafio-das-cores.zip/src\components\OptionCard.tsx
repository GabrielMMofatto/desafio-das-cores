/**
 * @file components/OptionCard.tsx
 * @description Card de alternativa lúdico e intuitivo para crianças.
 * Cada opção tem cor própria, ícone grande e rótulo claro.
 */

import React from 'react';
import {
  Star,
  Circle,
  Triangle,
  Square,
  Heart,
  Car,
  Ship,
  Fish,
  Sun,
  EyeOff,
  Check
} from 'lucide-react';
import { QuestionChoice, SymbolOrNumberType } from '../types';
import { soundService } from '../services/soundService';

interface OptionCardProps {
  choice: QuestionChoice;
  isSelected: boolean;
  onSelect: () => void;
  disabled?: boolean;
}

// Cores temáticas para cada símbolo — tornam os cards visualmente distintos
const SYMBOL_COLORS: Record<SymbolOrNumberType, { bg: string; icon: string; selectedBg: string }> = {
  star:     { bg: '#fff8e1', icon: '#f59e0b', selectedBg: '#fde68a' },
  circle:   { bg: '#e0f2fe', icon: '#0ea5e9', selectedBg: '#bae6fd' },
  triangle: { bg: '#f0fdf4', icon: '#22c55e', selectedBg: '#bbf7d0' },
  square:   { bg: '#fdf4ff', icon: '#a855f7', selectedBg: '#e9d5ff' },
  heart:    { bg: '#fff1f2', icon: '#f43f5e', selectedBg: '#fecdd3' },
  car:      { bg: '#eff6ff', icon: '#3b82f6', selectedBg: '#bfdbfe' },
  boat:     { bg: '#f0fdfa', icon: '#14b8a6', selectedBg: '#99f6e4' },
  fish:     { bg: '#ecfdf5', icon: '#10b981', selectedBg: '#a7f3d0' },
  sun:      { bg: '#fffbeb', icon: '#f97316', selectedBg: '#fed7aa' },
  num_2:    { bg: '#fef3c7', icon: '#d97706', selectedBg: '#fde68a' },
  num_5:    { bg: '#fce7f3', icon: '#ec4899', selectedBg: '#fbcfe8' },
  num_7:    { bg: '#ede9fe', icon: '#7c3aed', selectedBg: '#ddd6fe' },
  num_8:    { bg: '#e0f2fe', icon: '#0284c7', selectedBg: '#bae6fd' },
  none:     { bg: '#f1f5f9', icon: '#64748b', selectedBg: '#cbd5e1' },
};

/**
 * Renderiza o ícone correspondente ao símbolo com tamanho grande e traço firme
 */
const renderChoiceIcon = (symbol: SymbolOrNumberType, color: string) => {
  const sz = 44;
  const sw = 2.5;

  switch (symbol) {
    case 'star':
      return <Star size={sz} strokeWidth={sw} color={color} fill={color} opacity={0.9} />;
    case 'circle':
      return <Circle size={sz} strokeWidth={sw} color={color} fill={color} opacity={0.7} />;
    case 'triangle':
      return <Triangle size={sz} strokeWidth={sw} color={color} fill={color} opacity={0.8} />;
    case 'square':
      return <Square size={sz} strokeWidth={sw} color={color} fill={color} opacity={0.75} />;
    case 'heart':
      return <Heart size={sz} strokeWidth={sw} color={color} fill={color} opacity={0.9} />;
    case 'car':
      return <Car size={sz} strokeWidth={sw} color={color} />;
    case 'boat':
      return <Ship size={sz} strokeWidth={sw} color={color} />;
    case 'fish':
      return <Fish size={sz} strokeWidth={sw} color={color} />;
    case 'sun':
      return <Sun size={sz} strokeWidth={sw} color={color} fill={color} opacity={0.8} />;
    case 'num_2':
      return <span style={{ fontSize: '2.6rem', fontWeight: 900, color, lineHeight: 1 }}>2</span>;
    case 'num_5':
      return <span style={{ fontSize: '2.6rem', fontWeight: 900, color, lineHeight: 1 }}>5</span>;
    case 'num_7':
      return <span style={{ fontSize: '2.6rem', fontWeight: 900, color, lineHeight: 1 }}>7</span>;
    case 'num_8':
      return <span style={{ fontSize: '2.6rem', fontWeight: 900, color, lineHeight: 1 }}>8</span>;
    case 'none':
    default:
      return <EyeOff size={sz} strokeWidth={sw} color={color} />;
  }
};

export const OptionCard: React.FC<OptionCardProps> = ({
  choice,
  isSelected,
  onSelect,
  disabled = false
}) => {
  const theme = SYMBOL_COLORS[choice.symbol] ?? SYMBOL_COLORS.none;

  const handleClick = () => {
    if (disabled) return;
    soundService.playPop();
    onSelect();
  };

  return (
    <button
      type="button"
      role="radio"
      aria-checked={isSelected}
      disabled={disabled}
      onClick={handleClick}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleClick();
        }
      }}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '0.7rem',
        padding: '1.4rem 0.8rem 1.1rem',
        minHeight: '140px',
        backgroundColor: isSelected ? theme.selectedBg : theme.bg,
        border: `3px solid ${isSelected ? theme.icon : 'transparent'}`,
        borderRadius: '20px',
        boxShadow: isSelected
          ? `0 8px 24px ${theme.icon}55, 0 0 0 4px ${theme.icon}33`
          : '0 3px 10px rgba(0,0,0,0.07)',
        cursor: disabled ? 'not-allowed' : 'pointer',
        position: 'relative',
        outline: 'none',
        transform: isSelected ? 'scale(1.06)' : 'scale(1)',
        transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
        WebkitTapHighlightColor: 'transparent',
        userSelect: 'none',
      }}
      onMouseEnter={(e) => {
        if (!disabled && !isSelected) {
          e.currentTarget.style.transform = 'translateY(-4px) scale(1.03)';
          e.currentTarget.style.boxShadow = `0 10px 24px ${theme.icon}44`;
          e.currentTarget.style.border = `3px solid ${theme.icon}88`;
        }
      }}
      onMouseLeave={(e) => {
        if (!disabled && !isSelected) {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = '0 3px 10px rgba(0,0,0,0.07)';
          e.currentTarget.style.border = '3px solid transparent';
        }
      }}
    >
      {/* Selo de selecionado */}
      {isSelected && (
        <div
          className="animate-pop-in"
          style={{
            position: 'absolute',
            top: '8px',
            right: '8px',
            width: '28px',
            height: '28px',
            borderRadius: '50%',
            backgroundColor: theme.icon,
            color: '#ffffff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: `0 2px 8px ${theme.icon}66`
          }}
        >
          <Check size={17} strokeWidth={3} />
        </div>
      )}

      {/* Círculo do ícone */}
      <div
        style={{
          width: '72px',
          height: '72px',
          borderRadius: '50%',
          backgroundColor: isSelected ? `${theme.icon}22` : `${theme.icon}18`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.2s ease',
          border: `2px solid ${theme.icon}44`,
        }}
      >
        {renderChoiceIcon(choice.symbol, theme.icon)}
      </div>

      {/* Rótulo */}
      <span
        style={{
          fontFamily: 'var(--font-heading)',
          fontSize: '1.1rem',
          fontWeight: 800,
          color: isSelected ? theme.icon : '#334155',
          textAlign: 'center',
          lineHeight: 1.2,
          transition: 'color 0.2s ease',
        }}
      >
        {choice.label}
      </span>
    </button>
  );
};
