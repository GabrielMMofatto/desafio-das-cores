/**
 * @file pages/LevelResult.tsx
 * @description Tela de resultado de nível com feedback acolhedor do mascote Cromito,
 * métricas transparentes e download de relatório em PDF.
 */

import React from 'react';
import { Award, FileDown, ArrowRight } from 'lucide-react';
import { ChildData, LevelResult } from '../types';
import { StatBadge } from '../components/StatBadge';
import { generateLevelPdf } from '../services/pdfService';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { Mascot } from '../components/Mascot';
import { soundService } from '../services/soundService';

interface LevelResultProps {
  child: ChildData;
  result: LevelResult;
  onAdvance: () => void;
}

export const LevelResultView: React.FC<LevelResultProps> = ({ child, result, onAdvance }) => {
  const isLevel3 = result.levelNumber === 3;

  const handleDownloadPdf = () => {
    soundService.playPop();
    generateLevelPdf(child, result);
  };

  const handleAdvance = () => {
    soundService.playConfirm();
    onAdvance();
  };

  const getMascotMessage = () => {
    if (result.percentage >= 80) {
      return `Demais, ${child.name}! Você arrasou no ${result.levelName}! Vamos para o próximo?`;
    }
    return `Parabéns pelo seu esforço, ${child.name}! Cada desafio nos ensina mais sobre as cores!`;
  };

  return (
    <div className="animate-fade-in" style={{ maxWidth: '800px', margin: '0 auto', width: '100%' }}>
      <DisclaimerBanner compact />

      {/* Mascote celebrando */}
      <Mascot message={getMascotMessage()} emotion="celebrating" />

      <div className="card" style={{ padding: '2.25rem 1.75rem', backgroundColor: '#ffffff' }}>
        {/* Cabeçalho Festivo */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: '72px',
            height: '72px',
            margin: '0 auto 0.85rem auto',
            borderRadius: '50%',
            backgroundColor: '#ecfdf5',
            color: '#059669',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 4px 14px rgba(5, 150, 105, 0.2)'
          }}>
            <Award size={40} />
          </div>
          <h2 style={{ fontSize: '1.9rem', fontWeight: 800 }}>
            {result.levelName} Concluído! 🎉
          </h2>
          <p style={{ fontSize: '1.1rem', color: 'var(--text-secondary)' }}>
            Muito bem, <strong>{child.name}</strong>! Você completou esta etapa com sucesso!
          </p>
        </div>

        {/* Métricas do Nível em Blocos Coloridos */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
          gap: '1rem',
          marginBottom: '2rem'
        }}>
          {/* Total */}
          <div style={{
            padding: '1.1rem',
            backgroundColor: 'var(--bg-card-subtle)',
            borderRadius: 'var(--radius-xl)',
            textAlign: 'center'
          }}>
            <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)', fontWeight: 700, display: 'block' }}>
              TOTAL DE QUESTÕES
            </span>
            <span style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-main)' }}>
              {result.totalQuestions}
            </span>
          </div>

          {/* Acertos */}
          <div style={{
            padding: '1.1rem',
            backgroundColor: '#ecfdf5',
            borderRadius: 'var(--radius-xl)',
            textAlign: 'center',
            border: '2px solid #a7f3d0'
          }}>
            <span style={{ fontSize: '0.82rem', color: '#065f46', fontWeight: 700, display: 'block' }}>
              RESPOSTAS ESPERADAS
            </span>
            <span style={{ fontSize: '2rem', fontWeight: 900, color: '#059669' }}>
              {result.correctAnswers}
            </span>
          </div>

          {/* Divergências */}
          <div style={{
            padding: '1.1rem',
            backgroundColor: '#fff1f2',
            borderRadius: 'var(--radius-xl)',
            textAlign: 'center',
            border: '2px solid #fecdd3'
          }}>
            <span style={{ fontSize: '0.82rem', color: '#9f1239', fontWeight: 700, display: 'block' }}>
              DIVERGÊNCIAS
            </span>
            <span style={{ fontSize: '2rem', fontWeight: 900, color: '#e11d48' }}>
              {result.wrongAnswers}
            </span>
          </div>

          {/* Acurácia */}
          <div style={{
            padding: '1.1rem',
            backgroundColor: 'var(--brand-primary-light)',
            borderRadius: 'var(--radius-xl)',
            textAlign: 'center',
            border: '2px solid #c7d2fe'
          }}>
            <span style={{ fontSize: '0.82rem', color: 'var(--brand-primary)', fontWeight: 700, display: 'block' }}>
              ACURÁCIA
            </span>
            <span style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--brand-primary)' }}>
              {result.percentage}%
            </span>
          </div>
        </div>

        {/* Parecer Neutro de Triagem */}
        <div style={{
          padding: '1.4rem',
          backgroundColor: '#f8fafc',
          borderRadius: 'var(--radius-xl)',
          border: '1.5px solid var(--bg-muted)',
          marginBottom: '2rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem', flexWrap: 'wrap', gap: '0.5rem' }}>
            <h4 style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-main)' }}>
              Interpretação da Triagem ({result.levelName})
            </h4>
            <StatBadge status={result.indicativeStatus} />
          </div>

          <p style={{ fontSize: '0.96rem', color: 'var(--text-secondary)', lineHeight: 1.55 }}>
            {result.interpretation}
          </p>

          <p style={{
            fontSize: '0.9rem',
            color: 'var(--text-muted)',
            marginTop: '0.75rem',
            borderTop: '1px dashed #cbd5e1',
            paddingTop: '0.75rem'
          }}>
            <strong>Recomendação: </strong>{result.recommendation}
          </p>
        </div>

        {/* Botões de Ação */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '1rem',
          flexWrap: 'wrap'
        }}>
          {/* Botão de PDF deste nível */}
          <button
            type="button"
            onClick={handleDownloadPdf}
            className="btn btn-secondary"
            style={{ flex: 1, minWidth: '240px', fontSize: '1.05rem', minHeight: '54px' }}
          >
            <FileDown size={22} />
            <span>BAIXAR RELATÓRIO DO NÍVEL (PDF)</span>
          </button>

          {/* Avançar para o próximo nível */}
          <button
            type="button"
            onClick={handleAdvance}
            className="btn btn-primary btn-lg"
            style={{ flex: 1, minWidth: '240px', fontSize: '1.2rem' }}
          >
            <span>{isLevel3 ? 'VER RESULTADO GERAL' : `IR PARA O NÍVEL ${result.levelNumber + 1}`}</span>
            <ArrowRight size={22} />
          </button>
        </div>
      </div>
    </div>
  );
};
