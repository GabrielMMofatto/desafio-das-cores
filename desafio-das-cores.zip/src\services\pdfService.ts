/**
 * @file services/pdfService.ts
 * @description Geração de relatórios em PDF com formatação acadêmica profissional via jsPDF.
 * 
 * ATENDE AOS REQUISITOS DO TCC:
 * - Gera relatório de nível individual.
 * - Gera relatório consolidado da sessão completa (Níveis 1, 2 e 3).
 * - Apresenta cabeçalho padronizado, dados da criança, tabelas de desempenho,
 *   interpretação ética, recomendações e aviso médico em destaque.
 */

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ChildData, LevelResult, FullSessionResult } from '../types';

/**
 * Adiciona o cabeçalho institucional padrão no documento PDF
 */
function addPdfHeader(doc: jsPDF, title: string, subtitle: string) {
  const pageWidth = doc.internal.pageSize.getWidth();

  // Barra decorativa superior
  doc.setFillColor(79, 70, 229); // #4F46E5 Brand Primary
  doc.rect(0, 0, pageWidth, 8, 'F');

  // Título principal
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(30, 41, 59); // #1E293B
  doc.text(title, pageWidth / 2, 22, { align: 'center' });

  // Subtítulo
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(100, 116, 139); // #64748B
  doc.text(subtitle, pageWidth / 2, 29, { align: 'center' });

  // Linha divisória fina
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(14, 34, pageWidth - 14, 34);
}

/**
 * Adiciona o rodapé com a advertência médica obrigatória
 */
function addPdfFooter(doc: jsPDF) {
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Caixa de destaque para o aviso
  doc.setFillColor(254, 243, 199); // #FEF3C7 Amarelo suave
  doc.setDrawColor(245, 158, 11);  // #F59E0B
  doc.roundedRect(14, pageHeight - 32, pageWidth - 28, 22, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(146, 64, 14); // #92400E
  doc.text('IMPORTANTE:', 18, pageHeight - 24);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  const disclaimerText =
    'Este sistema é uma ferramenta educativa de triagem e NÃO substitui avaliação médica oftalmológica especializada. Nenhum dado deste relatório constitui diagnóstico de daltonismo ou de qualquer patologia ocular.';
  doc.text(doc.splitTextToSize(disclaimerText, pageWidth - 40), 18, pageHeight - 19);

  // Linha de identificação acadêmica
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text('Projeto TCC — Desafio das Cores | Triagem Visual Infantil', pageWidth / 2, pageHeight - 4, { align: 'center' });
}

/**
 * Gera o relatório em PDF de um nível individual
 */
export function generateLevelPdf(child: ChildData, level: LevelResult): void {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();

  addPdfHeader(doc, 'DESAFIO DAS CORES', 'RELATÓRIO DE TRIAGEM VISUAL — NÍVEL INDIVIDUAL');

  const now = new Date();
  const dateFormatted = now.toLocaleDateString('pt-BR');
  const timeFormatted = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

  // 1. Dados da Criança
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 41, 59);
  doc.text('1. Dados da Criança', 14, 44);

  autoTable(doc, {
    startY: 47,
    margin: { left: 14, right: 14 },
    theme: 'plain',
    styles: { fontSize: 9.5, cellPadding: 2.5, textColor: [51, 65, 85] },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 45 },
      1: { cellWidth: 135 }
    },
    body: [
      ['Nome da Criança:', child.name || 'Não informado'],
      ['Idade:', `${child.age} anos`],
      ['Responsável:', child.guardian || 'Não informado'],
      ['Data e Horário:', `${dateFormatted} às ${timeFormatted}`],
      ['Observações:', child.observation || 'Nenhuma observação registrada']
    ]
  });

  // 2. Resultado do Nível
  const afterChildY = (doc as any).lastAutoTable.finalY + 8;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 41, 59);
  doc.text('2. Resultado do Desafio', 14, afterChildY);

  autoTable(doc, {
    startY: afterChildY + 3,
    margin: { left: 14, right: 14 },
    theme: 'striped',
    headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9.5 },
    styles: { fontSize: 9, cellPadding: 3 },
    head: [['Métrica Avaliada', 'Resultado Registrado']],
    body: [
      ['Nível do Desafio:', `Nível ${level.levelNumber} — ${level.levelName}`],
      ['Tipo de Percepção Avaliado:', level.scientificName],
      ['Número de Questões:', String(level.totalQuestions)],
      ['Respostas Corretas:', String(level.correctAnswers)],
      ['Respostas Incorretas:', String(level.wrongAnswers)],
      ['Percentual de Acertos:', `${level.percentage}%`]
    ]
  });

  // 3. Interpretação Cuidadosa
  const afterTableY = (doc as any).lastAutoTable.finalY + 8;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('3. Interpretação da Triagem:', 14, afterTableY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(71, 85, 105);
  const splitInterp = doc.splitTextToSize(level.interpretation, pageWidth - 28);
  doc.text(splitInterp, 14, afterTableY + 6);

  // 4. Recomendação
  const interpHeight = splitInterp.length * 5;
  const afterInterpY = afterTableY + 6 + interpHeight + 4;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('4. Recomendação:', 14, afterInterpY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(71, 85, 105);
  const splitRec = doc.splitTextToSize(level.recommendation, pageWidth - 28);
  doc.text(splitRec, 14, afterInterpY + 6);

  addPdfFooter(doc);

  // Download do arquivo com nome amigável
  const safeName = (child.name || 'crianca').replace(/[^a-zA-Z0-9]/g, '_');
  doc.save(`Relatorio_Nivel_${level.levelNumber}_${safeName}.pdf`);
}

/**
 * Gera o relatório em PDF completo de toda a sessão (Níveis 1, 2 e 3 consolidados)
 */
export function generateFullSessionPdf(session: FullSessionResult): void {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();

  addPdfHeader(doc, 'DESAFIO DAS CORES', 'RELATÓRIO DE TRIAGEM VISUAL COMPLETA');

  // 1. Dados da Criança
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 41, 59);
  doc.text('1. Identificação da Criança e Sessão', 14, 42);

  autoTable(doc, {
    startY: 45,
    margin: { left: 14, right: 14 },
    theme: 'plain',
    styles: { fontSize: 9.5, cellPadding: 2.2, textColor: [51, 65, 85] },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 45 },
      1: { cellWidth: 135 }
    },
    body: [
      ['Nome da Criança:', session.child.name || 'Não informado'],
      ['Idade:', `${session.child.age} anos`],
      ['Responsável:', session.child.guardian || 'Não informado'],
      ['Data e Horário:', `${session.date} às ${session.time}`],
      ['Observações:', session.child.observation || 'Nenhuma observação registrada']
    ]
  });

  // 2. Tabela com os 3 Níveis
  const afterChildY = (doc as any).lastAutoTable.finalY + 6;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 41, 59);
  doc.text('2. Desempenho por Eixo de Visão de Cores', 14, afterChildY);

  const tableRows = session.levels.map((lvl) => [
    `Nível ${lvl.levelNumber}\n${lvl.levelName}`,
    lvl.scientificName,
    String(lvl.totalQuestions),
    String(lvl.correctAnswers),
    String(lvl.wrongAnswers),
    `${lvl.percentage}%`
  ]);

  // Linha totalizadora
  const totalQ = session.levels.reduce((a, b) => a + b.totalQuestions, 0);
  const totalC = session.levels.reduce((a, b) => a + b.correctAnswers, 0);
  const totalW = session.levels.reduce((a, b) => a + b.wrongAnswers, 0);
  tableRows.push(['TOTAL / GERAL', 'Média ponderada dos 3 eixos', String(totalQ), String(totalC), String(totalW), `${session.overallPercentage}%`]);

  autoTable(doc, {
    startY: afterChildY + 3,
    margin: { left: 14, right: 14 },
    theme: 'grid',
    headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
    styles: { fontSize: 8.5, cellPadding: 2.8, textColor: [30, 41, 59] },
    head: [['Desafio / Nível', 'Tipo de Percepção Avaliado', 'Questões', 'Acertos', 'Erros', 'Acurácia']],
    body: tableRows,
    didParseCell: (data) => {
      // Destaca a linha totalizadora
      if (data.row.index === session.levels.length) {
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.fillColor = [241, 245, 249];
      }
    }
  });

  // 3. Síntese e Interpretação
  const afterTableY = (doc as any).lastAutoTable.finalY + 6;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('3. Parecer Descritivo da Triagem:', 14, afterTableY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  const splitSynthesis = doc.splitTextToSize(session.overallSynthesis, pageWidth - 28);
  doc.text(splitSynthesis, 14, afterTableY + 5);

  // 4. Orientações aos Pais e Educadores
  const synHeight = splitSynthesis.length * 4.5;
  const afterSynY = afterTableY + 5 + synHeight + 4;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('4. Recomendações e Encaminhamento:', 14, afterSynY);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  const guidanceText =
    'Recomenda-se que este relatório seja apresentado aos pais ou responsáveis legais. Caso exista qualquer dúvida ou preocupação acerca do reconhecimento das cores pela criança nas atividades cotidianas ou escolares, orienta-se agendar consulta com médico oftalmologista para avaliação clínica completa através de testes diagnósticos padrão-ouro (como teste de Ishihara original impresso, Farnsworth-Munsell ou anomaloscópio de Nagel).';
  const splitGuidance = doc.splitTextToSize(guidanceText, pageWidth - 28);
  doc.text(splitGuidance, 14, afterSynY + 5);

  addPdfFooter(doc);

  const safeName = (session.child.name || 'crianca').replace(/[^a-zA-Z0-9]/g, '_');
  doc.save(`Relatorio_Completo_Triagem_${safeName}.pdf`);
}
