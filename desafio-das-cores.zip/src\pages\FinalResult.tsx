/**
 * @file pages/FinalResult.tsx
 * @description Tela de conclusão geral com confetes, mascote Cromito,
 * efeitos sonoros e geração do relatório consolidado em PDF.
 */

import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, FileDown, RotateCcw, Home as HomeIcon, FileText } from 'lucide-react';
import { FullSessionResult } from '../types';
import { StatBadge } from '../components/StatBadge';
import { generateFullSessionPdf } from '../services/pdfService';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { Mascot } from '../components/Mascot';
import { soundService } from '../services/soundService';

interface FinalResultProps {
  session: FullSessionResult;
  onNewGame: () => void;
  onGoHome: () => void;
  onOpenHistory: () => void;
}

export const FinalResult: React.FC<FinalResultProps> = ({
  session,
  onNewGame,
  onGoHome,
  onOpenHistory
}) => {
  useEffect(() => {
    // Efeito suave de confetes coloridos
    try {
      soundService.playLevelVictory();
      confetti({
        particleCount: 90,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // Degrada graciosamente
    }
  }, []);

  const handleDownloadFullPdf = () => {
    soundService.playPop();
    generateFullSessionPdf(session);
  };

  return (
    <div className="animate-fade-in" style={{ maxWidth: '860px', margin: '0 auto', width: '100%' }}>
      <DisclaimerBanner />

      {/* Mascote celebrando com a criança */}
      <Mascot
        message={`UAU, ${session.child.name}! Você é incrível! Completou todos os três mundos coloridos com maestria!`}
        emotion="celebrating"
      />

      <div className="card" style={{ padding: '2.5rem 2rem', backgroundColor: '#ffffff' }}>
        {/* Banner do Vencedor */}
        <div style={{ textAlign: 'center', marginBottom: '2.25rem' }}>
          <div style={{
            width: '84px',
            height: '84px',
            margin: '0 auto 1.25rem auto',
            borderRadius: '50%',
            backgroundColor: '#fef3c7',
            color: '#d97706',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 8px 24px rgba(217, 119, 6, 0.25)'
          }}>
            <Trophy size={46} />
          </div>
          <span className="badge badge-info" style={{ marginBottom: '0.5rem', fontWeight: 800 }}>
            MISSÃO CUMPRIDA! 🏆
          </span>
          <h2 style={{ fontSize: '2.2rem', fontWeight: 900 }}>
            Parabéns, {session.child.name}! 🌟
          </h2>
          <p style={{ fontSize: '1.2rem', color: 'var(--text-secondary)' }}>
            Você desvendou todos os três desafios do jogo das cores!
          </p>
        </div>

        {/* Grade com os 3 Cards de Nível */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: '1.1rem',
          marginBottom: '2.25rem'
        }}>
          {session.levels.map((lvl) => (
            <div
              key={lvl.levelNumber}
              className="card"
              style={{
                padding: '1.4rem',
                borderTop: `6px solid ${
                  lvl.levelNumber === 1 ? '#ef4444' : lvl.levelNumber === 2 ? '#10b981' : '#3b82f6'
                }`,
                backgroundColor: '#ffffff'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.6rem' }}>
                <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-muted)' }}>
                  NÍVEL {lvl.levelNumber}
                </span>
                <span style={{
                  fontSize: '1.6rem',
                  fontWeight: 900,
                  color: 'var(--brand-primary)'
                }}>
                  {lvl.percentage}%
                </span>
              </div>

              <h4 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '0.3rem' }}>
                {lvl.levelName}
              </h4>
              <p style={{ fontSize: '0.84rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
                {lvl.scientificName}
              </p>

              <div style={{ marginTop: 'auto' }}>
                <StatBadge status={lvl.indicativeStatus} />
              </div>
            </div>
          ))}
        </div>

        {/* Resumo e Parecer Geral */}
        <div style={{
          padding: '1.5rem',
          backgroundColor: '#f8fafc',
          borderRadius: 'var(--radius-xl)',
          border: '2px solid #e2e8f0',
          marginBottom: '2.25rem'
        }}>
          <h4 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '0.5rem', color: 'var(--text-main)' }}>
            Síntese Geral da Triagem:
          </h4>
          <p style={{ fontSize: '1.02rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
            {session.overallSynthesis}
          </p>

          <p style={{
            fontSize: '0.92rem',
            color: '#92400e',
            backgroundColor: '#fffbeb',
            padding: '0.9rem 1.1rem',
            borderRadius: 'var(--radius-lg)',
            marginTop: '1.2rem',
            border: '1.5px solid #fef3c7',
            lineHeight: 1.5
          }}>
            <strong>Aviso de Triagem:</strong> Os resultados apresentados são indicativos e têm finalidade exclusivamente pedagógica e de triagem. Caso exista qualquer preocupação sobre a visão de cores da criança, recomenda-se consultar um médico oftalmologista para uma avaliação completa.
          </p>
        </div>

        {/* Botões de Ação */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '1rem'
        }}>
          {/* Baixar PDF Completo */}
          <button
            type="button"
            onClick={handleDownloadFullPdf}
            className="btn btn-primary btn-lg"
            style={{ fontSize: '1.15rem' }}
          >
            <FileDown size={22} />
            <span>BAIXAR RELATÓRIO COMPLETO (PDF)</span>
          </button>

          {/* Histórico */}
          <button
            type="button"
            onClick={onOpenHistory}
            className="btn btn-secondary btn-lg"
            style={{ fontSize: '1.15rem' }}
          >
            <FileText size={22} />
            <span>VER HISTÓRICO</span>
          </button>

          {/* Novo Desafio */}
          <button
            type="button"
            onClick={onNewGame}
            className="btn btn-outline"
            style={{ fontSize: '1.1rem' }}
          >
            <RotateCcw size={20} />
            <span>NOVO DESAFIO</span>
          </button>

          {/* Voltar ao Início */}
          <button
            type="button"
            onClick={onGoHome}
            className="btn btn-outline"
            style={{ fontSize: '1.1rem' }}
          >
            <HomeIcon size={20} />
            <span>VOLTAR AO INÍCIO</span>
          </button>
        </div>
      </div>
    </div>
  );
};
