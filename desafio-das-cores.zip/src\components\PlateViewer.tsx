/**
 * @file components/PlateViewer.tsx
 * @description Renderizador vetorial SVG de alta definição para Placas Pseudoisocromáticas.
 * Apresentação ampliada, moldura lúdica e instruções claras para crianças.
 */

import React, { useMemo, useState } from 'react';
import { ZoomIn, ZoomOut, Eye } from 'lucide-react';
import { generatePseudoisochromaticPlate, GeneratedPlate } from '../data/plateGenerators';
import { DeficiencyAxis, SymbolOrNumberType } from '../types';

interface PlateViewerProps {
  plateId: string;
  plateType: DeficiencyAxis;
  targetFigure: SymbolOrNumberType;
  prompt: string;
}

export const PlateViewer: React.FC<PlateViewerProps> = ({
  plateId,
  plateType,
  targetFigure,
  prompt
}) => {
  const [isZoomed, setIsZoomed] = useState(false);

  // Geração determinística baseada no ID da questão
  const plate: GeneratedPlate = useMemo(() => {
    let seed = 1337;
    for (let i = 0; i < plateId.length; i++) {
      seed = (seed * 31 + plateId.charCodeAt(i)) & 0xffffffff;
    }
    return generatePseudoisochromaticPlate(plateId, plateType, targetFigure, seed);
  }, [plateId, plateType, targetFigure]);

  const plateSize = isZoomed ? '420px' : '340px';

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '1.25rem 0 1rem 0',
        gap: '0.75rem',
      }}
    >
      {/* Moldura externa com efeito de brilho */}
      <div
        className="animate-pop-in"
        style={{
          position: 'relative',
          width: plateSize,
          maxWidth: '95vw',
          aspectRatio: '1 / 1',
          transition: 'width 0.35s cubic-bezier(0.34, 1.56, 0.64, 1)',
        }}
      >
        {/* Halo externo decorativo (arco-íris suave) */}
        <div
          style={{
            position: 'absolute',
            inset: '-6px',
            borderRadius: '50%',
            background: 'conic-gradient(from 0deg, #f43f5e33, #f97316aa, #facc15aa, #22c55eaa, #3b82f6aa, #a855f7aa, #f43f5e33)',
            filter: 'blur(4px)',
            zIndex: 0,
          }}
        />

        {/* Moldura circular branca */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: '50%',
            backgroundColor: '#ffffff',
            border: '6px solid #e2e8f0',
            boxShadow: '0 16px 48px rgba(0,0,0,0.12), 0 4px 12px rgba(0,0,0,0.06)',
            overflow: 'hidden',
            zIndex: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <svg
            viewBox={`0 0 ${plate.width} ${plate.height}`}
            role="img"
            aria-label={`Placa de teste visual: ${prompt}`}
            style={{
              width: '100%',
              height: '100%',
              borderRadius: '50%',
              display: 'block',
            }}
          >
            {/* Fundo do disco */}
            <circle
              cx={plate.width / 2}
              cy={plate.height / 2}
              r={162}
              fill="#f8fafc"
            />

            {/* Pontos do mosaico */}
            {plate.dots.map((dot, index) => (
              <circle
                key={`${plate.id}_dot_${index}`}
                cx={dot.x}
                cy={dot.y}
                r={dot.radius}
                fill={dot.color}
              />
            ))}
          </svg>
        </div>

        {/* Botão de zoom */}
        <button
          type="button"
          onClick={() => setIsZoomed(!isZoomed)}
          title={isZoomed ? 'Reduzir' : 'Ampliar'}
          aria-label={isZoomed ? 'Reduzir imagem' : 'Ampliar imagem'}
          style={{
            position: 'absolute',
            bottom: '6px',
            right: '6px',
            zIndex: 2,
            width: '44px',
            height: '44px',
            borderRadius: '50%',
            backgroundColor: '#ffffff',
            border: '2px solid #c7d2fe',
            boxShadow: '0 3px 10px rgba(0,0,0,0.18)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            color: '#4f46e5',
            transition: 'transform 0.15s ease, box-shadow 0.15s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'scale(1.12)';
            e.currentTarget.style.boxShadow = '0 5px 16px rgba(79,70,229,0.3)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)';
            e.currentTarget.style.boxShadow = '0 3px 10px rgba(0,0,0,0.18)';
          }}
        >
          {isZoomed ? <ZoomOut size={20} /> : <ZoomIn size={20} />}
        </button>
      </div>

      {/* Instrução de distância e link de zoom */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          fontSize: '0.85rem',
          color: '#64748b',
          background: '#f8fafc',
          border: '1px solid #e2e8f0',
          borderRadius: '999px',
          padding: '0.35rem 1rem',
        }}
      >
        <Eye size={15} color="#94a3b8" />
        <span>Olhe a cerca de <strong>40–50 cm</strong> da tela.</span>
        <button
          type="button"
          onClick={() => setIsZoomed(!isZoomed)}
          style={{
            background: 'none',
            border: 'none',
            color: '#4f46e5',
            fontWeight: 700,
            cursor: 'pointer',
            textDecoration: 'underline',
            fontSize: '0.85rem',
            padding: 0,
          }}
        >
          {isZoomed ? 'Ver menor' : 'Ver maior'}
        </button>
      </div>
    </div>
  );
};
