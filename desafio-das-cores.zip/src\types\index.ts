/**
 * @file types/index.ts
 * @description Modelos de dados e definições de tipos para o sistema de triagem visual infantil.
 * Projeto acadêmico de TCC: "Desafio das Cores".
 */

export interface ChildData {
  name: string;
  age: number;
  guardian?: string;
  observation?: string;
}

export type SymbolOrNumberType =
  | 'star'
  | 'circle'
  | 'triangle'
  | 'square'
  | 'heart'
  | 'car'
  | 'boat'
  | 'fish'
  | 'sun'
  | 'num_2'
  | 'num_5'
  | 'num_7'
  | 'num_8'
  | 'none';

export interface QuestionChoice {
  id: string;
  label: string;
  symbol: SymbolOrNumberType;
}

export type DeficiencyAxis = 'protan' | 'deutan' | 'tritan' | 'control';

export interface Question {
  id: string;
  levelNumber: 1 | 2 | 3;
  plateType: DeficiencyAxis;
  targetFigure: SymbolOrNumberType;
  prompt: string;
  choices: QuestionChoice[];
  correctChoiceId: string;
  difficulty: 'controle' | 'facil' | 'padrao';
  axisDescription: string;
  scientificContext: string;
}

export interface LevelConfig {
  levelNumber: 1 | 2 | 3;
  friendlyName: string;
  scientificName: string;
  deficiencyType: DeficiencyAxis;
  coneType: string;
  colorTheme: string;
  description: string;
  questions: Question[];
}

export type IndicativeStatus = 'sem_indicios' | 'indicios_leves' | 'indicios_significativos';

export interface LevelResult {
  levelNumber: 1 | 2 | 3;
  type: DeficiencyAxis;
  levelName: string;
  scientificName: string;
  totalQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  percentage: number;
  indicativeStatus: IndicativeStatus;
  interpretation: string;
  recommendation: string;
  answers: Array<{
    questionId: string;
    chosenChoiceId: string;
    correctChoiceId: string;
    isCorrect: boolean;
    targetFigure: SymbolOrNumberType;
  }>;
}

export interface FullSessionResult {
  id: string;
  date: string;
  time: string;
  timestamp: number;
  child: ChildData;
  levels: LevelResult[];
  overallPercentage: number;
  overallSynthesis: string;
  ethicalDisclaimer: string;
}

export type AppScreen =
  | 'HOME'
  | 'REGISTRATION'
  | 'INSTRUCTIONS'
  | 'GAME_LEVEL'
  | 'LEVEL_RESULT'
  | 'FINAL_RESULT'
  | 'REPORTS_HISTORY';
