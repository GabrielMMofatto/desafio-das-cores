/**
 * @file data/levelsData.ts
 * @description Configuração dos 3 níveis de teste e banco de questões estruturado.
 * 
 * ESTRUTURA ACADÊMICA:
 * - Nível 1: Eixo Protan (Cores Vermelhas / Cones L - Eritrolábio)
 * - Nível 2: Eixo Deutan (Cores Verdes / Cones M - Clorolábio)
 * - Nível 3: Eixo Tritan (Cores Azuis / Cones S - Cianolábio)
 * 
 * Cada nível inclui placa de demonstração/controle para validação de compreensão pela criança.
 */

import { LevelConfig } from '../types';

export const LEVELS_CONFIG: LevelConfig[] = [
  {
    levelNumber: 1,
    friendlyName: 'Desafio das Cores Vermelhas',
    scientificName: 'Triagem para Protanopia / Protanomalia (Eixo Vermelho - Cone L)',
    deficiencyType: 'protan',
    coneType: 'Fotopigmento Eritrolábio (Sensibilidade em ~564nm - Cones L)',
    colorTheme: '#ef4444',
    description: 'Neste desafio, avaliamos a diferenciação de tons avermelhados em relação a tonalidades oliva e cáqui.',
    questions: [
      {
        id: 'q1_1_ctrl',
        levelNumber: 1,
        plateType: 'control',
        targetFigure: 'star',
        prompt: 'Qual figura mágica você vê dentro deste círculo?',
        difficulty: 'controle',
        axisDescription: 'Placa de controle de alto contraste para verificar se a criança compreendeu a dinâmica.',
        scientificContext: 'Verificação de acuidade basal e engajamento cognitivo infantil.',
        choices: [
          { id: 'c1', label: 'Estrela', symbol: 'star' },
          { id: 'c2', label: 'Círculo', symbol: 'circle' },
          { id: 'c3', label: 'Triângulo', symbol: 'triangle' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c1'
      },
      {
        id: 'q1_2_tri',
        levelNumber: 1,
        plateType: 'protan',
        targetFigure: 'triangle',
        prompt: 'Observe com calma: qual símbolo aparece no círculo?',
        difficulty: 'padrao',
        axisDescription: 'Figura vermelha em fundo verde-oliva/cáqui. Avalia discriminação do eixo protan.',
        scientificContext: 'Eixo de confusão Protan da CIE 1931: diferenciação entre tons de eritrolábio.',
        choices: [
          { id: 'c1', label: 'Triângulo', symbol: 'triangle' },
          { id: 'c2', label: 'Quadrado', symbol: 'square' },
          { id: 'c3', label: 'Coração', symbol: 'heart' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c1'
      },
      {
        id: 'q1_3_boat',
        levelNumber: 1,
        plateType: 'protan',
        targetFigure: 'boat',
        prompt: 'Que meio de transporte está escondido entre as bolinhas?',
        difficulty: 'padrao',
        axisDescription: 'Figura de barco estilizada em pigmento vermelho-coral com ruído de luminância.',
        scientificContext: 'Testa capacidade de integração de contornos complexos sob confusão protan.',
        choices: [
          { id: 'c1', label: 'Carro', symbol: 'car' },
          { id: 'c2', label: 'Barco', symbol: 'boat' },
          { id: 'c3', label: 'Peixe', symbol: 'fish' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c2'
      },
      {
        id: 'q1_4_heart',
        levelNumber: 1,
        plateType: 'protan',
        targetFigure: 'heart',
        prompt: 'Qual desenho com carinho você consegue enxergar?',
        difficulty: 'padrao',
        axisDescription: 'Coração estilizado em tons de terracota/coral com fundo de cáqui-esverdeado.',
        scientificContext: 'Estímulo afetivo lúdico facilitador para crianças na faixa de 4 a 10 anos.',
        choices: [
          { id: 'c1', label: 'Estrela', symbol: 'star' },
          { id: 'c2', label: 'Círculo', symbol: 'circle' },
          { id: 'c3', label: 'Coração', symbol: 'heart' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c3'
      },
      {
        id: 'q1_5_fish',
        levelNumber: 1,
        plateType: 'protan',
        targetFigure: 'fish',
        prompt: 'Qual bichinho do fundo do mar está nadando aí?',
        difficulty: 'facil',
        axisDescription: 'Peixe em tons salmão/coral sobre matriz verde-oliva.',
        scientificContext: 'Reconhecimento zoófilo adaptado para triagem de visão infantil.',
        choices: [
          { id: 'c1', label: 'Peixe', symbol: 'fish' },
          { id: 'c2', label: 'Barco', symbol: 'boat' },
          { id: 'c3', label: 'Sol', symbol: 'sun' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c1'
      },
      {
        id: 'q1_6_num5',
        levelNumber: 1,
        plateType: 'protan',
        targetFigure: 'num_5',
        prompt: 'E agora, você consegue reconhecer este número?',
        difficulty: 'padrao',
        axisDescription: 'Dígito numérico 5 em paleta protan com múltiplos níveis de brilho.',
        scientificContext: 'Avaliação de símbolos numéricos clássicos em placas pseudoisocromáticas.',
        choices: [
          { id: 'c1', label: 'Número 2', symbol: 'num_2' },
          { id: 'c2', label: 'Número 5', symbol: 'num_5' },
          { id: 'c3', label: 'Número 8', symbol: 'num_8' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c2'
      }
    ]
  },
  {
    levelNumber: 2,
    friendlyName: 'Desafio das Cores Verdes',
    scientificName: 'Triagem para Deuteranopia / Deuteranomalia (Eixo Verde - Cone M)',
    deficiencyType: 'deutan',
    coneType: 'Fotopigmento Clorolábio (Sensibilidade em ~534nm - Cones M)',
    colorTheme: '#10b981',
    description: 'Neste desafio, avaliamos a diferenciação de tons esverdeados em relação a tonalidades castanhas e terrosas.',
    questions: [
      {
        id: 'q2_1_ctrl',
        levelNumber: 2,
        plateType: 'control',
        targetFigure: 'car',
        prompt: 'Qual veículo de quatro rodas você vê aqui?',
        difficulty: 'controle',
        axisDescription: 'Placa de controle inicial do Nível 2.',
        scientificContext: 'Controle de transição e reconfirmação de foco atencional.',
        choices: [
          { id: 'c1', label: 'Barco', symbol: 'boat' },
          { id: 'c2', label: 'Carro', symbol: 'car' },
          { id: 'c3', label: 'Peixe', symbol: 'fish' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c2'
      },
      {
        id: 'q2_2_circle',
        levelNumber: 2,
        plateType: 'deutan',
        targetFigure: 'circle',
        prompt: 'Que forma geométrica arredondada está desenhada?',
        difficulty: 'padrao',
        axisDescription: 'Círculo em verde-folha sobre matriz terrosa/castanho-suave.',
        scientificContext: 'Eixo de confusão Deuteran: diferenciação dos cones M.',
        choices: [
          { id: 'c1', label: 'Quadrado', symbol: 'square' },
          { id: 'c2', label: 'Círculo', symbol: 'circle' },
          { id: 'c3', label: 'Triângulo', symbol: 'triangle' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c2'
      },
      {
        id: 'q2_3_heart',
        levelNumber: 2,
        plateType: 'deutan',
        targetFigure: 'heart',
        prompt: 'Qual símbolo de amor você encontra escondido nas bolinhas?',
        difficulty: 'padrao',
        axisDescription: 'Coração estilizado em verde-esmeralda sobre fundo terroso/marrom.',
        scientificContext: 'Discriminação de contornos orgânicos na deficiência visual deutan.',
        choices: [
          { id: 'c1', label: 'Estrela', symbol: 'star' },
          { id: 'c2', label: 'Coração', symbol: 'heart' },
          { id: 'c3', label: 'Peixe', symbol: 'fish' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c2'
      },
      {
        id: 'q2_4_sun',
        levelNumber: 2,
        plateType: 'deutan',
        targetFigure: 'sun',
        prompt: 'Qual elemento do céu ensolarado você consegue ver?',
        difficulty: 'facil',
        axisDescription: 'Sol estilizado em verde-menta sobre bege-terracota com ruído de luminância.',
        scientificContext: 'Estímulo de média frequência espacial sob confusão deutan.',
        choices: [
          { id: 'c1', label: 'Coração', symbol: 'heart' },
          { id: 'c2', label: 'Sol', symbol: 'sun' },
          { id: 'c3', label: 'Barco', symbol: 'boat' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c2'
      },
      {
        id: 'q2_5_star',
        levelNumber: 2,
        plateType: 'deutan',
        targetFigure: 'star',
        prompt: 'Qual figura brilhante do céu noturno está aí?',
        difficulty: 'padrao',
        axisDescription: 'Estrela de 5 pontas verde sobre fundo de pigmento marrom-claro.',
        scientificContext: 'Padrão com pontas finas para testar discriminação de alta frequência.',
        choices: [
          { id: 'c1', label: 'Estrela', symbol: 'star' },
          { id: 'c2', label: 'Triângulo', symbol: 'triangle' },
          { id: 'c3', label: 'Quadrado', symbol: 'square' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c1'
      },
      {
        id: 'q2_6_num2',
        levelNumber: 2,
        plateType: 'deutan',
        targetFigure: 'num_2',
        prompt: 'Que número simpático está escondido nas cores?',
        difficulty: 'padrao',
        axisDescription: 'Dígito numérico 2 em paleta verde-clorolábio.',
        scientificContext: 'Morfologia com curvas e retas na avaliação deuteranômala.',
        choices: [
          { id: 'c1', label: 'Número 7', symbol: 'num_7' },
          { id: 'c2', label: 'Número 5', symbol: 'num_5' },
          { id: 'c3', label: 'Número 2', symbol: 'num_2' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c3'
      }
    ]
  },
  {
    levelNumber: 3,
    friendlyName: 'Desafio das Cores Azuis',
    scientificName: 'Triagem para Tritanopia / Tritanomalia (Eixo Azul - Cone S)',
    deficiencyType: 'tritan',
    coneType: 'Fotopigmento Cianolábio (Sensibilidade em ~420nm - Cones S)',
    colorTheme: '#3b82f6',
    description: 'Neste desafio, avaliamos a diferenciação entre tons azulados/violetas e tons amarelados.',
    questions: [
      {
        id: 'q3_1_ctrl',
        levelNumber: 3,
        plateType: 'control',
        targetFigure: 'heart',
        prompt: 'Qual desenho com carinho você vê aqui?',
        difficulty: 'controle',
        axisDescription: 'Placa de controle inicial do Nível 3.',
        scientificContext: 'Controle de contraste do terceiro nível.',
        choices: [
          { id: 'c1', label: 'Coração', symbol: 'heart' },
          { id: 'c2', label: 'Estrela', symbol: 'star' },
          { id: 'c3', label: 'Círculo', symbol: 'circle' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c1'
      },
      {
        id: 'q3_2_square',
        levelNumber: 3,
        plateType: 'tritan',
        targetFigure: 'square',
        prompt: 'Qual forma de 4 lados iguais você consegue identificar?',
        difficulty: 'padrao',
        axisDescription: 'Quadrado em amarelo-mostarda sobre matriz azul-celeste.',
        scientificContext: 'Eixo de confusão Tritan (azul-amarelo, cones S).',
        choices: [
          { id: 'c1', label: 'Triângulo', symbol: 'triangle' },
          { id: 'c2', label: 'Quadrado', symbol: 'square' },
          { id: 'c3', label: 'Círculo', symbol: 'circle' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c2'
      },
      {
        id: 'q3_3_fish',
        levelNumber: 3,
        plateType: 'tritan',
        targetFigure: 'fish',
        prompt: 'Que bichinho aquático você encontra nesta placa?',
        difficulty: 'padrao',
        axisDescription: 'Peixe em amarelo-limão sobre fundo azulado.',
        scientificContext: 'Discriminação tritan com figura orgânica familiar.',
        choices: [
          { id: 'c1', label: 'Peixe', symbol: 'fish' },
          { id: 'c2', label: 'Barco', symbol: 'boat' },
          { id: 'c3', label: 'Carro', symbol: 'car' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c1'
      },
      {
        id: 'q3_4_tri',
        levelNumber: 3,
        plateType: 'tritan',
        targetFigure: 'triangle',
        prompt: 'Qual forma geométrica com 3 pontas você vê?',
        difficulty: 'facil',
        axisDescription: 'Triângulo em amarelo-dourado com fundo azul/lavanda.',
        scientificContext: 'Confusão cromática de cianolábio com forma de 3 vértices.',
        choices: [
          { id: 'c1', label: 'Quadrado', symbol: 'square' },
          { id: 'c2', label: 'Estrela', symbol: 'star' },
          { id: 'c3', label: 'Triângulo', symbol: 'triangle' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c3'
      },
      {
        id: 'q3_5_car',
        levelNumber: 3,
        plateType: 'tritan',
        targetFigure: 'car',
        prompt: 'Que veículo motorizado está estacionado aí?',
        difficulty: 'padrao',
        axisDescription: 'Carro em amarelo sobre matriz azulada com ruído de luminância.',
        scientificContext: 'Estímulo de resolução tritan em silhueta de veículo.',
        choices: [
          { id: 'c1', label: 'Barco', symbol: 'boat' },
          { id: 'c2', label: 'Carro', symbol: 'car' },
          { id: 'c3', label: 'Sol', symbol: 'sun' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c2'
      },
      {
        id: 'q3_6_num8',
        levelNumber: 3,
        plateType: 'tritan',
        targetFigure: 'num_8',
        prompt: 'Para finalizar, que número com duas voltinhas você vê?',
        difficulty: 'padrao',
        axisDescription: 'Dígito numérico 8 no eixo tritan.',
        scientificContext: 'Fechamento da triagem com símbolo numérico no eixo cianolábio.',
        choices: [
          { id: 'c1', label: 'Número 2', symbol: 'num_2' },
          { id: 'c2', label: 'Número 5', symbol: 'num_5' },
          { id: 'c3', label: 'Número 8', symbol: 'num_8' },
          { id: 'c4', label: 'Não vejo nada', symbol: 'none' }
        ],
        correctChoiceId: 'c3'
      }
    ]
  }
];

export function getLevelConfig(levelNumber: 1 | 2 | 3): LevelConfig {
  const config = LEVELS_CONFIG.find((l) => l.levelNumber === levelNumber);
  if (!config) {
    throw new Error(`Nível ${levelNumber} não encontrado.`);
  }
  return config;
}
