/**
 * @file App.tsx
 * @description Componente raiz da aplicação "Desafio das Cores".
 * Controla o roteamento de telas, estado da criança, progressão dos 3 níveis
 * e persistência automática dos relatórios.
 */

import React, { useState } from 'react';
import { AppScreen, ChildData, LevelResult, FullSessionResult } from './types';
import { getLevelConfig } from './data/levelsData';
import { evaluateLevelAnswers, synthesizeFullSession } from './services/assessmentService';
import { storageService } from './services/storageService';

import { Header } from './components/Header';
import { Footer } from './components/Footer';

import { Home } from './pages/Home';
import { ChildRegistration } from './pages/ChildRegistration';
import { Instructions } from './pages/Instructions';
import { GameLevel } from './pages/GameLevel';
import { LevelResultView } from './pages/LevelResult';
import { FinalResult } from './pages/FinalResult';
import { ReportsHistory } from './pages/ReportsHistory';

export const App: React.FC = () => {
  // Estado da tela atual
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('HOME');

  // Dados da criança participante
  const [childData, setChildData] = useState<ChildData | null>(null);

  // Controle de progressão dos níveis (1, 2 e 3)
  const [currentLevelNumber, setCurrentLevelNumber] = useState<1 | 2 | 3>(1);
  const [completedLevels, setCompletedLevels] = useState<LevelResult[]>([]);
  const [latestLevelResult, setLatestLevelResult] = useState<LevelResult | null>(null);

  // Sessão final consolidada
  const [fullSessionResult, setFullSessionResult] = useState<FullSessionResult | null>(null);

  // ==========================================
  // Navegação e Fluxo Principal
  // ==========================================

  // Início do fluxo: clique em JOGAR na Home
  const handleStartGame = () => {
    setCurrentScreen('REGISTRATION');
  };

  // Clique em RELATÓRIOS
  const handleOpenReports = () => {
    setCurrentScreen('REPORTS_HISTORY');
  };

  // Conclusão do cadastro da criança
  const handleRegisterChild = (data: ChildData) => {
    setChildData(data);
    setCurrentScreen('INSTRUCTIONS');
  };

  // Início do teste após as instruções
  const handleStartLevel1 = () => {
    setCompletedLevels([]);
    setLatestLevelResult(null);
    setFullSessionResult(null);
    setCurrentLevelNumber(1);
    setCurrentScreen('GAME_LEVEL');
  };

  // Conclusão de um nível específico
  const handleFinishLevel = (answersMap: Record<string, string>) => {
    const levelConfig = getLevelConfig(currentLevelNumber);
    const result = evaluateLevelAnswers(levelConfig, answersMap);

    const updatedLevels = [...completedLevels, result];
    setCompletedLevels(updatedLevels);
    setLatestLevelResult(result);
    setCurrentScreen('LEVEL_RESULT');
  };

  // Avanço após a tela de resultado parcial do nível
  const handleAdvanceLevel = async () => {
    if (currentLevelNumber === 1) {
      setCurrentLevelNumber(2);
      setCurrentScreen('GAME_LEVEL');
    } else if (currentLevelNumber === 2) {
      setCurrentLevelNumber(3);
      setCurrentScreen('GAME_LEVEL');
    } else if (currentLevelNumber === 3) {
      // Todos os 3 níveis concluídos: sintetiza e salva no histórico
      if (childData) {
        const session = synthesizeFullSession(childData, completedLevels);
        setFullSessionResult(session);

        // Salva automaticamente no LocalStorage
        try {
          await storageService.save(session);
        } catch (err) {
          console.error('Falha ao salvar sessão no histórico:', err);
        }

        setCurrentScreen('FINAL_RESULT');
      }
    }
  };

  // Reiniciar para um novo teste
  const handleNewGame = () => {
    setChildData(null);
    setCompletedLevels([]);
    setLatestLevelResult(null);
    setFullSessionResult(null);
    setCurrentLevelNumber(1);
    setCurrentScreen('REGISTRATION');
  };

  // Retornar à tela inicial
  const handleGoHome = () => {
    setCurrentScreen('HOME');
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* Barra de Navegação Superior */}
      <Header currentScreen={currentScreen} onNavigate={setCurrentScreen} />

      {/* Conteúdo da Tela Ativa */}
      <main className="app-container">
        {currentScreen === 'HOME' && (
          <Home
            onStartGame={handleStartGame}
            onOpenReports={handleOpenReports}
          />
        )}

        {currentScreen === 'REGISTRATION' && (
          <ChildRegistration
            onRegister={handleRegisterChild}
            onCancel={handleGoHome}
          />
        )}

        {currentScreen === 'INSTRUCTIONS' && childData && (
          <Instructions
            child={childData}
            onStartLevel1={handleStartLevel1}
            onBack={() => setCurrentScreen('REGISTRATION')}
          />
        )}

        {currentScreen === 'GAME_LEVEL' && (
          <GameLevel
            key={`level_${currentLevelNumber}`}
            levelConfig={getLevelConfig(currentLevelNumber)}
            onFinishLevel={handleFinishLevel}
          />
        )}

        {currentScreen === 'LEVEL_RESULT' && childData && latestLevelResult && (
          <LevelResultView
            child={childData}
            result={latestLevelResult}
            onAdvance={handleAdvanceLevel}
          />
        )}

        {currentScreen === 'FINAL_RESULT' && fullSessionResult && (
          <FinalResult
            session={fullSessionResult}
            onNewGame={handleNewGame}
            onGoHome={handleGoHome}
            onOpenHistory={handleOpenReports}
          />
        )}

        {currentScreen === 'REPORTS_HISTORY' && (
          <ReportsHistory
            onBackToHome={handleGoHome}
            onStartNewGame={handleNewGame}
          />
        )}
      </main>

      {/* Rodapé com Aviso Médico Permanente */}
      <Footer />
    </div>
  );
};
