/**
 * @file pages/Instructions.tsx
 * @description Tela de instruções lúdica com dicas ilustradas e mascote Cromito.
 */

import React from 'react';
import { Sun, Monitor, Ruler, CheckCircle, ArrowRight, ArrowLeft } from 'lucide-react';
import { ChildData } from '../types';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { Mascot } from '../components/Mascot';

interface InstructionsProps {
  child: ChildData;
  onStartLevel1: () => void;
  onBack: () => void;
}

export const Instructions: React.FC<InstructionsProps> = ({ child, onStartLevel1, onBack }) => {
  return (
    <div className="animate-fade-in" style={{ maxWidth: '760px', margin: '0 auto', width: '100%' }}>
      <DisclaimerBanner compact />

      {/* Mascote com fala amigável */}
      <Mascot
        message={`Legal te conhecer, ${child.name}! Vamos preparar seu cantinho com luz e distância certa antes de começar?`}
        emotion="happy"
      />

      <div className="card" style={{ padding: '2.25rem 2rem', backgroundColor: '#ffffff' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <h2 style={{ fontSize: '1.85rem', fontWeight: 800 }}>
            Dicas Importantes do Desafio 🚀
          </h2>
          <p style={{ fontSize: '1.15rem', color: 'var(--text-secondary)', marginTop: '0.4rem' }}>
            Observe as cores com atenção e responda da melhor maneira que você conseguir!
          </p>
        </div>

        {/* Recomendações em Cards Coloridos */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem', marginBottom: '2rem' }}>
          {/* Iluminação */}
          <div style={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '1.1rem',
            padding: '1.25rem',
            backgroundColor: '#fffbeb',
            borderRadius: 'var(--radius-xl)',
            border: '2px solid #fde68a'
          }}>
            <div style={{
              width: '48px',
              height: '48px',
              borderRadius: '50%',
              backgroundColor: '#fef3c7',
              color: '#d97706',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}>
              <Sun size={28} />
            </div>
            <div>
              <h4 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#92400e' }}>
                1. Ambiente Bem Iluminado ☀️
              </h4>
              <p style={{ fontSize: '0.96rem', color: '#78350f', marginTop: '0.25rem' }}>
                Fique em uma sala clara com iluminação natural ou lâmpada branca. Evite reflexos de luz diretamente em cima da tela do aparelho.
              </p>
            </div>
          </div>

          {/* Configuração da Tela */}
          <div style={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '1.1rem',
            padding: '1.25rem',
            backgroundColor: '#eff6ff',
            borderRadius: 'var(--radius-xl)',
            border: '2px solid #bfdbfe'
          }}>
            <div style={{
              width: '48px',
              height: '48px',
              borderRadius: '50%',
              backgroundColor: '#dbeafe',
              color: '#2563eb',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}>
              <Monitor size={28} />
            </div>
            <div>
              <h4 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#1e40af' }}>
                2. Tela com Cores Naturais 🖥️
              </h4>
              <p style={{ fontSize: '0.96rem', color: '#1e3a8a', marginTop: '0.25rem' }}>
                Certifique-se de desativar o "Modo Noturno", "Filtro de Luz Azul" ou "True Tone", para que a tela não fique amarelada durante o teste.
              </p>
            </div>
          </div>

          {/* Distância */}
          <div style={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '1.1rem',
            padding: '1.25rem',
            backgroundColor: '#ecfdf5',
            borderRadius: 'var(--radius-xl)',
            border: '2px solid #a7f3d0'
          }}>
            <div style={{
              width: '48px',
              height: '48px',
              borderRadius: '50%',
              backgroundColor: '#d1fae5',
              color: '#059669',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}>
              <Ruler size={28} />
            </div>
            <div>
              <h4 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#065f46' }}>
                3. Distância Confortável 📏
              </h4>
              <p style={{ fontSize: '0.96rem', color: '#064e3b', marginTop: '0.25rem' }}>
                Fique a cerca de <strong>40 a 50 centímetros</strong> da tela (estique o seu braço: essa é a distância ideal dos seus olhos!).
              </p>
            </div>
          </div>
        </div>

        {/* Lembrete da dinâmica */}
        <div style={{
          backgroundColor: '#f8fafc',
          borderRadius: 'var(--radius-lg)',
          padding: '1rem 1.25rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem',
          fontSize: '0.95rem',
          color: 'var(--text-secondary)',
          marginBottom: '2rem',
          border: '1px solid var(--bg-muted)'
        }}>
          <CheckCircle size={22} color="var(--brand-primary)" style={{ flexShrink: 0 }} />
          <span>
            Não existe tempo limite! Você pode olhar com calma e escolher o botão correspondente. Se não tiver certeza, pode clicar em <strong>"Não vejo nada"</strong>.
          </span>
        </div>

        {/* Ações */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '1rem'
        }}>
          <button
            type="button"
            onClick={onBack}
            className="btn btn-outline"
            style={{ fontSize: '1.05rem' }}
          >
            <ArrowLeft size={18} />
            <span>Voltar</span>
          </button>

          <button
            type="button"
            onClick={onStartLevel1}
            className="btn btn-primary btn-lg"
            style={{ flex: 1, fontSize: '1.35rem', gap: '0.85rem' }}
          >
            <span>ESTOU PRONTO! COMEÇAR</span>
            <ArrowRight size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};
